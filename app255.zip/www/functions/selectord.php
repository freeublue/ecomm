<table width='800px' border=1><tr><td width='500px' valign='top'>
<?php
include "../../confadmin.php";
require "../../lib.php";
$sql = $db->query("SELECT * FROM ordval");


while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 


echo "$row[ordnum]<br />";
echo "$row[res]<br />";
echo "<br />"; } 
?>
</td><td width='100px' valign='top'><a href='index.php'>Home</a></td></tr></table>
