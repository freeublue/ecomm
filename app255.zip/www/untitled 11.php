<?
echo "<table>";
include "../confad.php";
$sq = $db->query("SELECT
        tempord.tm_wsid,
        tempord.tm_clientid,
        workshop2.ws_id,
        workshop2.ws_title,
        workshop2.ws_price,
        workshop2.ws_datefr,
        workshop2.ws_timefr,
        workshop2.ws_timeto,
        workshop2.ws_discount,
        workshop2.ws_descp
        
FROM tempord  

INNER JOIN workshop2 ON
        tempord.tm_wsid = workshop2.ws_id WHERE tempord.tm_clientid = '9'");
        while($rowg = $sq->fetchArray(SQLITE3_ASSOC ) ) { 

               if($sub == 'y') { 
        
        $newprice = $rowg[ws_price] - ($rowg[ws_price] * ($rowg[ws_discount]/100)); } else { $newprice = $rowg[ws_price]; } 
        $wsid = $rowg[ws_id];
        echo "wk id $wsid<br>";
        $discountcr = $rowg[ws_discount_criteria];
        $ft = $rowg[ws_descp];
        $totadds[] = $newprice;
           $mobile = $_POST[mb];
$emailx = $_POST[em];
$fname = $_POST[name_first];
$lname = $_POST[name_last];

$pt = $_POST[paytype];
$ti = 'workshop';
$subad = $_POST[subad];
$orstatus = 2;

$tb = "wsorders";


$day = date("Y-m-d");
$timep = date("H:i");

  
        
        echo "<tr><td>$rowg[ws_title]</td>";
echo "<td>R $rowg[ws_price]</td>";
echo "<td>$rowg[ws_datefr]</td>";
echo "<td><b>From:</b> $rowg[ws_timefr]<br>";
echo "<b>To:</b> $rowg[ws_timeto]</td>";
echo "<td>$rowg[ws_discount] %</td><td></td></tr>";
  
        } 
        $total = array_sum($totadds);
        echo "</table>TotaL $total";