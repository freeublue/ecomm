<?
session_start();

require "bootstraptop.php";
require "functions/bootlib.php";
$size = 'xl';
$bootcolor = 'light';
$bootcolor2 = 'light';
$navname = 'Groups Club';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Start A Group >>', 'startgroup.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);

$day = date("Y-m-d");
$year = date("Y");
$md = date("m-d");
$nextyear = $year +1;

if(isset($_SESSION[customer]) ) {  
?>
<div class='container-fluid'>
<style>

#conf1{padding:10px;
color:;
background:#eee7e0; 
border-radius:0px 30px 30px 0px;}
#confirm{background:;}

#conf2{padding:10px;
color:;
background:;
border-right:1px solid #ceb7a2;
border-radius:0px 30px 30px 0px;}
#conf3{padding:10px;
color:;
background:;
border-right:1px solid #ceb7a2;
border-radius:0px 30px 30px 0px; }
#arrow_box {
	position: relative;
	background: ;
	border: 1px solid #0d020f;
}
#arrow_box:after, .arrow_box:before {
	left: 100%;
	top: 50%;
	border: solid transparent;
	content: " ";
	height: 0;
	width: 0;
	position: absolute;
	pointer-events: none;
}

#arrow_box:after {
	border-color: rgba(242, 242, 242, 0);
	border-left-color: ;
	border-width: 90px;
	margin-top: -90px;
}
#arrow_box:before {
	border-color: rgba(13, 2, 15, 0);
	border-left-color: #0d020f;
	border-width: 91px;
	margin-top: -91px;
}
</style>
<?
$sb_id = $_REQUEST[sb_id];

$id = "confirm";
$size = 3;
$rule = 'text-center';
$colsize = 'col-4';
$gg = array('conf1', 'conf2', 'conf3');
$contentarray[0] = "<h5>Confirm >></h5>";
$contentarray[1] = "<h5>Payment >></h5>";
$contentarray[2] = "<h5>Notification >></h5>";
rowcol($id, $rule, $size, $contentarray, $colsize, $gg);


?>
<div style='margin-top:5em;' class='row'>
<div class='col-6'><h4 style='border-bottom:1px solid ;color:#ceb7a2;padding-bottom:6px;'>Confirm Subscription</h4><p style='color:;'><? echo $day; ?></p><form action='pap.php' method='post'>
<?
require "../confad.php";
require "../lib.php";
$customer = cr($stp, ($_SESSION[customer]), $action = 'enc');
$sqlc = $db->query("SELECT * FROM cust1 WHERE cu_phone_mobile = '$customer'");
while($row = $sqlc->fetchArray(SQLITE3_ASSOC) ) { 
$newcustid = $row[cu_id];

$input_id = 'name_first';
$input_type = 'text';
$input_label = 'First Name';
$size = 'col-6';
 input_formv($input_id, $input_type, $input_label, $size, $row[cu_fname]);
 $input_ids = 'name_last';
$input_type = 'text';
$input_labels = 'Last Name';
$size = 'col-6';
 input_formv($input_ids, $input_type, $input_labels, $size, $row[cu_lname]);
 $input_idx = 'em';
$input_typex = 'email';
$input_labelx = 'Email';
$size = 'col-6';
$email = cr($stp, $row[cu_email], $action = 'ivg');
 input_formv($input_idx, $input_typex, $input_labelx, $size, $email); } 
 
$sqlc = $db->query("SELECT * FROM subscription WHERE sb_id = '$sb_id'");
while($row = $sqlc->fetchArray(SQLITE3_ASSOC) ) { 
$sbname = $row[sb_title];
$sbprice = $row[sb_price];

 $input_idxd = 'amount';
$input_typexd = 'text';
$input_labelxd = $sbname;
$size = 'col-6';
echo "<input type='hidden' name='id' value='$sb_id' /><br>";
 input_formv($input_idxd, $input_typexd, $input_labelxd, $size, $sbprice); } 
 
 
?>
<h4>Select Payment Method</h4><input type="radio" value='cc' name="paytype" checked>Credit Card
<input type="radio" value='dc' name="paytype">Debit Card
<input type="radio" value='eft' name="paytype">EFT
<input type="radio" value='mc' name="paytype">Mobicred<br>

<input style='background:#ed8a63;color:gray;' type='submit' class='btn text-uppercase' value='submit' name='submit' /></form>

</div>
<div class='col-6'><h4 style='border-bottom:1px solid ;color:#ceb7a2;padding-bottom:6px;'>Subscription Details</h4><p>Cancel renewal at any time prior to payment date, your next payment will be <p style='color:;'><? echo " $nextyear $md"; ?></p></p>
<div class="card mb-5 mb-lg-0">
          <div class="card-body">
            <h5 class="card-title text-muted text-uppercase text-center">Annual Subscription</h5>
            <h6 class="card-price text-center">R550<span class="period">/Year</span></h6>
            <hr>
            <ul class="fa-ul">
              <li><span style='color:;' class="fa-li"><i class="fas fa-check"></i></span>R50 discount on first 100 subscribers</li>
              <li><span style='color:;' class="fa-li"><i class="fas fa-check"></i></span>Covers 12 months mentorship activities</li>
              <li><span style='color:;' class="fa-li"><i class="fas fa-check"></i></span>Discounts on events and workshops</li>
              <li><span style='color:;' class="fa-li"><i class="fas fa-check"></i></span>Discount on organized ticket for events and workshops</li>
      
            </ul>
            
          </div>
        </div>
      </div>

</div>
</div>





<? } 

else { echo "You must be logged in to proceed"; 

?>
<div class='row'>

<div class='col-6'>
      <form name='rform' onsubmit='return validateForm();' action='loginredir.php' method='post' class="form-signin">
        <h2 class="form-signin-heading">Login</h2>
        <label for="input" class="sr-only">Mobile Number</label>
        <input type="input" name='mobile' id="mobile" class="form-control" placeholder="Mobile number" required autofocus>
        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" id="password" name='password' class="form-control" placeholder="Password" required>
        <div class="checkbox">
          <label>
            <input type="checkbox" value="remember-me"> Remember me
          </label>
        </div>
        <button class="btn btn-md btn-dark btn-block" type="submit">Sign in</button>
      </form>
</div>
<div class='col-6'>

<form action='regredir.php' method='post' class="form-signin" onsubmit='return validateForm2();' name='rform2' id='form3'><h2 class="form-signin-heading">Enter your mobile number and select a password.</h2><p>Password can be letters and numbers only, no spaces in username or password. password must be 6 or more characters</p>
       <label for="input" class="sr-only">Mobile Number</label>
        <input type="input" name='us' id="us" class="form-control" placeholder="Mobile number" required autofocus>
        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" id="ps" name='ps' class="form-control" placeholder="Password" required>
         <label for="inputPassword" class="sr-only">Repeat Password</label>
        <input type="password" id="psr" name='psr' class="form-control" placeholder="Repeat Password" required>
       
        <button class="btn btn-md btn-dark btn-block" type="submit">Sign in</button>
      </form>
<p>By registering you agree to the terms and conditions as set out<a style='color:red;' href='terms.php'>Here</a></p></div>
</div>


</div>







<?
 } 
 require "footer.php";
 ?> 
 



</div><!container>

<?
require "bootstrapbottom.php";
?>