<?php
session_start();


require "bootstraptop.php";
require "functions/bootlib.php";
$foo = $_SERVER[SERVER_NAME];

require "header.php";
echo "<div class='container'>";
if($foo === '127.0.0.1') { 
$mobile = $_POST[mobile];
$pass = $_POST[password];

include "../confad.php";
include "../lib.php";

$us = cr($stp, $mobile, $action = 'enc');
$q = $db->query("SELECT * FROM cust1 WHERE cu_phone_mobile = '$us'");
while($ro = $q->fetchArray(SQLITE3_ASSOC) ) { 


$numrows = count($ro[cu_phone_mobile]);

$ref = $ro[cu_ps];
} 
if ($numrows == 1) { 
$q1 = $db->query("SELECT * FROM str WHERE ca = '$ref'");
while($ro = $q1->fetchArray(SQLITE3_ASSOC) ) { 


$ps = $ro[pf];

 } 

} 
if($ps == crypt($_POST['password'], $ps)) { 

$_SESSION[customer] = $mobile;
$groupid = $_POST[groupid];

echo "<div class='row'>";
echo "<div class='col-12 text-center'>";
echo "<a style='width:200px;height:200px;background:black;color:white;border:1px solid #ceb7a2;border-radius:15%;padding:30px;font-size:40px;margin-bottom:200px;' href='groupspage.php?$groupid'>Click Here To Proceed with purchase</a>"; 
echo "</div></div>";

} else { 
echo "<div class='row'>";
echo "<div class='col-12'>";
echo "<h4>No that is not correct please try again or use <a href='lostpassword.php'>Lost Password</a></h4>";
echo "</div></div>";
 } } else { 
echo " "; } 
require "footer.php";
?>



</div><!container>

<?
require "bootstrapbottom.php";
?>
