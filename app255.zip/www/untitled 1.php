<?
require "boottopnewsletter.php";
require "../confad.php";
require "functions/bootlib.php";
?>


<div class='container-fluid'>

<div class='row'>

<div class='col-3'>
<p><img height='100px' src='logo.png' /></p>
</div></div>


<div class='row'>

<div class='col-12'>
<img width='100%' class='img-fluid' src='newsletterbanner.jpg' />
</div>

</div><!row>
<div class='row'>
<div class='col-6'><h1 style='font-size:28px;text-align:center;border-bottom:1px solid red;padding:4px;'>Categories</h1>
<?
$sql = $db->query("SELECT * FROM groupcate");
while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 
echo "<h5 style='color:#ed8a63;padding:8px;height:10px;'>$row[gc_title]</h5><p style='color:#ceb7a2;height:20px;'>$row[gc_descp]</p><p><img src='$row[gc_image]' height='50px' style='margin-top:1em;' class='rounded-circle' /></p><p class='text-center'><a class='btn btn-sm btn-outline-warning' href='categorygroup.php?id=$row[gc_id]' role='button'>View</a></p>"; } 
?>
</div>
<div class='col-6'><h1 style='font-size:28px;text-align:center;border-bottom:1px solid red;padding:4px;'>Latest Additions</h1>

</div>
</div><!row>
<?
require "footer.php";
?>




 








</div><!container>

<?
require "bootstrapbottom.php";
?>