<?
session_start();
$cookie_name = "cust";
$cookie_value = $_SESSION['customer'];
setcookie($cookie_name, $cookie_value, time() + (86400 * 1), "/");
require "bootstraptop.php";
require "functions/bootlib.php";
require "../confad.php";
error_reporting(0);
?>
<style>

#conf1{padding:10px;
color:;
background:#eee7e0; 
border-radius:0px 30px 30px 0px;}
#confirm{background:;}

#conf2{padding:10px;
color:;
background:;
border-right:1px solid #ceb7a2;
border-radius:0px 30px 30px 0px;}
#conf3{padding:10px;
color:;
background:;
border-right:1px solid #ceb7a2;
border-radius:0px 30px 30px 0px; }
</style>
<script>
function validateForm()
{
var x=document.forms["mform"]["name_first"].value;
if (x==null || x=="")
  {
  alert("First Name must be filled out");
  return false;
  } 


var xc=document.forms["mform"]["name_last"].value;
if (xc==null || xc=="")
  {
  alert("Last Name must be filled out");
  return false;
  } 
  var xc1=document.forms["mform"]["em"].value;
if (xc1==null || xc1=="")
  {
  alert("Email must be filled out");
  return false;
  } 
   



}
</script>
<?
$size = 'xl';
$bootcolor = 'light';
$bootcolor2 = 'light';
$navname = 'Groups Club';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Categories >>', 'categories.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);
echo "<div class='container-fluid'>";

if(isset($_SESSION[customer] ) ) { 
require "../lib.php";

$id = "confirm";
$size = 3;
$rule = 'text-center';
$colsize = 'col-4';
$gg = array('conf1', 'conf2', 'conf3');
$contentarray[0] = "<h5>Confirm >></h5>";
$contentarray[1] = "<h5>Payment >></h5>";
$contentarray[2] = "<h5>Notification >></h5>";
rowcol($id, $rule, $size, $contentarray, $colsize, $gg);
$customer = cr($stp, ($_COOKIE[cust]), $action = 'enc');
echo "<form name='mform' onsubmit='return validateForm();' action='checkout.php' method='post'>";
$sqlc = $db->query("SELECT * FROM cust1 WHERE cu_phone_mobile = '$customer'");
while($row = $sqlc->fetchArray(SQLITE3_ASSOC) ) { 
$newcustid = $row[cu_id]; 
$sub = $row[cu_subscriptionstatus];
$input_id = 'name_first';
$input_type = 'text';
$input_label = 'First Name';
$size = 'col-6';
 input_formv($input_id, $input_type, $input_label, $size, $row[cu_fname]);
 $input_ids = 'name_last';
$input_type = 'text';
$input_labels = 'Last Name';
$size = 'col-6';
 input_formv($input_ids, $input_type, $input_labels, $size, $row[cu_lname]);
 $input_idx = 'em';
$input_typex = 'email';
$input_labelx = 'Email';
$size = 'col-6';
$email = cr($stp, $row[cu_email], $action = 'ivg');
 input_formv($input_idx, $input_typex, $input_labelx, $size, $email); } 
 
 
 
?>
<h4>Select Payment Method</h4><input type="radio" value='cc' name="paytype" checked>Credit Card
<input type="radio" value='dc' name="paytype">Debit Card
<input type="radio" value='eft' name="paytype">EFT
<input type="radio" value='mc' name="paytype">Mobicred<br>

<?



echo "<div class='row'>
<div class='col-12 text-center'><h4>Confirm Details of your Purchase before Checkout</h4></div></div>";
echo "<div id='cartDetails'><table width='100%'><tr><td>Workshop</td><td>Price</td><td>Date</td><td>Time</td><td>Discount</td><td>Remove</td></tr>";
$sq = $db->query("SELECT
tempord.tm_id,
        tempord.tm_wsid,
        tempord.tm_clientid,
        workshop2.ws_id,
        workshop2.ws_title,
        workshop2.ws_price,
        workshop2.ws_datefr,
        workshop2.ws_timefr,
        workshop2.ws_timeto,
        workshop2.ws_discount,
        workshop2.ws_descp
FROM tempord  

INNER JOIN workshop2 ON
        tempord.tm_wsid = workshop2.ws_id WHERE tempord.tm_clientid = '$newcustid'");
        while($rowg = $sq->fetchArray(SQLITE3_ASSOC ) ) { 
        if($sub == 'y') { 
        
        $newprice = $rowg[ws_price] - ($rowg[ws_price] * ($rowg[ws_discount]/100)); } else { $newprice = $rowg[ws_price]; } 
        echo "new price $newprice<br>";
        $totadds[] = $newprice;
        
        echo "<tr><td>$rowg[ws_title]</td>";
echo "<td>R $rowg[ws_price]</td>";
echo "<td>$rowg[ws_datefr]</td>";
echo "<td><b>From:</b> $rowg[ws_timefr]<br>";
echo "<b>To:</b> $rowg[ws_timeto]</td>";
echo "<td>$rowg[ws_discount] %</td><td id='$rowg[tm_id]' onclick='deleteFromCart(this.id);'>x</td></tr>";
        } 
        $total = array_sum($totadds);
        echo "<tr><td colspan='5'></td><td>R $total</td></tr></table></div>";
echo "<input type='submit' class='btn btn-dark' value='Check Out' /></form><br>";
echo "<div id='resultsh'></div><form name='custdet'><input type='hidden' name='custid' value='$newcustid' /></form>";
} else { 
echo "<a href='login.php'>Please login to access this information</a>"; } 
include "footer.php";
?>
</div>
<?
include "bootstrapbottom.php";
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js" type="text/javascript"></script>
<script>

var nam;
function deleteFromCart(nam) { 
$.ajaxSetup({ cache: false });
$("#resultsh").show();

document.getElementById("cartDetails").style.display = "none";
var cu = document.custdet.custid.value;
var url = "deletecart.php?nam="+nam+"&&cu="+cu;
$('#resultsh').load(url);
} 
</script>
