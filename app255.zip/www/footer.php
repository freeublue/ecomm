

<div  style='background: #3a4660;color:#f9f7f4;margin-top:1em;' class='row text-center'>

<div  class='col-12'>
<h2>Areas and Info</h2>
<h4>Discover Groups</h4></div>
</div>


<?
echo "<div  style='background: #3a4660;color:#f9f7f4;padding:12px;' class='row'>";
echo "<div  class='col-4'>";
echo "<b style='color:#eee7e0;'>Provincial Groups</b>";

$sql = $db->query("SELECT * FROM locate LIMIT 0, 30 ");
while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 
$province[] = $row[lc_title];
$pid[] = $row[lc_id]; } 
$sizesx = 9;
$stylex = 'liststy';
$listx = 'ul';
$clax = 'list-unstyled';
$contx = array("<a style='text-decoration:none;color:#f9f7f4;' href='groupsbyprovince.php?province=$pid[0]'>$province[0]</a>", "<a style='text-decoration:none;color:#f9f7f4;' href='groupsbyprovince.php?province=$pid[1]'>$province[1]</a>", "<a style='text-decoration:none;color:#f9f7f4;' href='groupsbyprovince.php?province=$pid[2]'>$province[2]</a>", "<a style='text-decoration:none;color:#f9f7f4;' href='groupsbyprovince.php?province=$pid[3]'>$province[3]</a>", "<a style='text-decoration:none;color:#f9f7f4;' href='groupsbyprovince.php?province=$pid[4]'>$province[4]</a>", "<a style='text-decoration:none;color:#f9f7f4;' href='groupsbyprovince.php?province=$pid[5]'>$province[5]</a>", "<a style='text-decoration:none;color:#f9f7f4;' href='groupsbyprovince.php?province=$pid[6]'>$province[6]</a>", "<a style='text-decoration:none;color:#f9f7f4;' href='groupsbyprovince.php?province=$pid[7]'>$province[7]</a>", "<a style='text-decoration:none;color:#f9f7f4;' href='groupsbyprovince.php?province=$pid[8]'>$province[8]</a>");
$optstylex = array('tt1', 'tt2', 'tt3', 'tt4', 'tt5', 'tt6');
$lisx = blist($stylex, $listx, $clax, $sizex, $contx, $optstylex);
echo $lisx;
?>




</div>
<div  class='col-4'><b style='color:#eee7e0;'>Featured Groups</b></div>
<div  class='col-4'><b style='color:#eee7e0;'>Services</b></div>
</div>

<div  style='background: #3a4660;color:#f9f7f4;' class='row text-center'>

<div  class='col-12'>
<p class="m-0 text-center text-#f9f7f4">Copyright &copy; Groups Club 2018</p><p style='text-align:center;'><i class="fab fa-twitter fa-1x" style='color:#ed8a63;'></i><i class="fab fa-instagram fa-1x" style='color:#ed8a63;'></i><i class="fab fa-facebook-f fa-1x" style='color:#ed8a63;'></i></p><p><img height='30px' src='vm.png' /></p>
</div>

</div>
