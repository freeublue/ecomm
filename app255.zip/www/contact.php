<?
$title = 'Contact Public Service Internship Club';
require "bootstraptop.php";
require "functions/bootlib.php";

require "header.php";

?>


<div class='container-fluid'>

<div class='row'>

<div id='headimage' class='col-12 text-center'>
<h1 style='margin-top:550px;' >Public Service Internship Club</h1><h4 style='margin-top:30px;' >Some Text</h4><p><a class="btn btn-block btn-light" href="#" role="button">Join</a></p><p style='margin-top:50px;'>More text</p>
</div>

</div>


<div style='margin-top:2em;' class='row text-center'>

<div class='col-2'><i style='color:#eee7e0;' class="fas fa-graduation-cap"></i><p>Learn</p>
</div>
<div class='col-2'><i style='color:#eee7e0;' class="fas fa-chalkboard"></i><p>Teach</p>
</div>
<div class='col-2'><i style='color:#eee7e0;' class="fas fa-chalkboard-teacher"></i><p>Meet</p>
</div>
<div class='col-2'><i style='color:#eee7e0;' class="fas fa-chalkboard"></i><p>Connect</p>
</div>
<div class='col-2'><i style='color:#eee7e0;' class="fas fa-laptop"></i><p>Improve</p>
</div>
<div class='col-2'><i style='color:#eee7e0;' class="fas fa-desktop"></i><p>Instruct</p>
</div>




</div>


<div  style='background: ;' class='row text-center'>

<div style='padding:10px;border-bottom:1px solid ;background:;' class='col-12'>
<h2>Public Service Internship Club</h2>
<h4>Organizing Internship Meet-ups</h4>
<p style='color:;'>------ <i class="fab fa-twitter fa-1x" style='color:;'></i><i class="fab fa-instagram fa-1x" style='color:;'></i><i class="fab fa-facebook-f fa-1x" style='color:;'></i> ------</p>
<p>Mission Statment Mission Statment Mission Statment Mission Statment Mission Statment </p>
<p>Mission Statment Mission Statment Mission Statment Mission Statment Mission Statment </p>
<p>Mission Statment Mission Statment Mission Statment Mission Statment Mission Statment </p>
<p>Mission Statment Mission Statment Mission Statment Mission Statment Mission Statment </p>
</div></div>

 <div style='margin-top:5em;' class='row'>
     <div class='col-md-6'><h4 class='text-left'>Address</h4><p>
     <?
     
        require "../confad.php";
        $sq = $db->query("SELECT * FROM businessaddress LIMIT 1");
        
        while($ro = $sq->fetchArray(SQLITE3_ASSOC) ) { 
  echo "<strong>$ro[webname]</strong><br>
  $ro[address1], $ro[address2]<br>
  $ro[suburb], $ro[town], $ro[state], $ro[zip]<br><abbr title='Phone'>P:</abbr> $ro[landline]<br><abbr title='Phone'>P:</abbr> $ro[mobile]</address><address><strong>$ro[webname]</strong><br><a href='mailto:". $ro[email] . "'>". $ro[email] . "</a></address>"; 
  } 
  ?>
     </p></div>
    <div class='col-md-6'><h4 class='text-left'>Contact</h4><p><form method='post' class="form-horizontal" action="processcontact.php">
          <div class="form-group">
    <label class="control-label col-sm-4" for="name">Name:</label>
    <div class="col-sm-12"> 
      <input class='bor' type="text" class="form-control" name='name' id="name" placeholder="Enter name">
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-4" for="email">Email:</label>
    <div class="col-sm-12">
      <input class='bor' type="email" class="form-control" name='email' id="email" placeholder="Enter email">
    </div>
  </div>
<div class='form-group'><label class="control-label col-sm-4" for='descp'>Enter Message :</label><br /><div class="col-sm-12"><textarea class='bor' cols='40' rows='10' name='message'></textarea></div></div>
<?php

$firsta = range(1,50,4);
$seconda = range(1,50,2);
shuffle($firsta);
shuffle($seconda);
$sum = $firsta[0] + $seconda[0];
echo 'What is the sum of ' . $firsta[0] . '+' . $seconda[0] . "<br />";
echo "<input type='hidden' name='chk' value='$sum' /><input type='text' name='chkhuman'/><br />";

?>


  <div class="form-group"> 
    <div class="col-sm-10">
      <button type="submit" name='submit' class="btn btn-sm btn-warning">Send</button>
    </div>
  </div>
</form></div></div>



<?
require "footer.php";
?>


</div><!container>

<?
require "bootstrapbottom.php";
?>

