<?
session_start();

require "bootstraptop.php";
require "functions/bootlib.php";
$size = 'xl';
$bootcolor = 'light';
$bootcolor2 = 'light';
$navname = 'Public Service Internship Club';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Categories >>', 'categories.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);
$_SESSION[customer] = '0726060893';
if(isset($_SESSION[customer]) ) {  
?>
<div class='container-fluid'>

<div class='row text-center'>
<div class='col-12'><h1 style='font-size:28px;text-align:center;border-bottom:1px solid red;padding:4px;'>Workshop Title</h1><p>Workshop Description</p><p>Price</p><p>R500</p><button type="button" class="btn btn-outline-danger">Add to Cart</button><button type="button" class="btn btn-danger">Buy Now</button></p>
</div>
</div>


<div class='row'>
<div class='col-12'> <div class="card-group">
<div class="card"><div class="card-header text-center">Workshop Leader</div>
      <img class="card-img-top img-fluid" src="face9.jpg" alt="Card image cap">
    
    <div class="card-body">
      <h5 class="card-title">Assisting Students</h5>
      <p style='color:gray;' class="card-text">Dedicated to improving education.</p><p>
<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
    </div>
    <div class="card-footer text-center">
      <h4 class="text-muted text-center">2018</h4>
    </div>
  </div>



<div class="card"><div class="card-header text-center">Workshop Title</div>
      <img class="card-img-top img-fluid" src="solar.jpg" alt="Card image cap">
    
    <div class="card-body">
      <h5 class="card-title">Workshop description</h5>
      <p style='color:gray;' class="card-text">Workshop Motto.</p><p>
<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p><hr><h3>Features : </h3>
            <ul class="fa-ul">
              <li><span style='color:#d9534f;' class="fa-li"><i class="fas fa-check"></i></span>3 hour mentorship</li>
              <li><span style='color:#d9534f;' class="fa-li"><i class="fas fa-check"></i></span>Covers important areas</li>
              <li><span style='color:#d9534f;' class="fa-li"><i class="fas fa-check"></i></span>Certificate on completion</li>
              <li><span style='color:#d9534f;' class="fa-li"><i class="fas fa-check"></i></span>Discount for subscription members</li>
      
            </ul><h5>Date: <span style='color:#d9534f;font-weight:lighter;font-size:18px;'>2018-12-15</span></h5><h5>Time: <span style='color:#d9534f;font-weight:lighter;font-size:18px;' >15:00pm</span> </h5><h5>Duration: <span style='color:#d9534f;font-weight:lighter;font-size:18px;'>3hr</span></h5><p>
            <address>
            <strong>Workshop</strong><br>
  10, My St<br>
  suburb, town, state, zip<br><abbr title='Phone'>P:</abbr> landline<br><abbr title='Phone'>P:</abbr> mobile</address><address><strong>webname</strong><br><a href='mailto:email'>email</a></address>
            
    </div>
    <div class="card-footer text-center">
      <h4 class="text-muted text-center">R500</h4>
    </div>
  </div></div>

</div>
</div>






<div  style='background: black;color:white;' class='row text-center'>
<? } 

else { echo "You must be logged in to proceed"; } 
?>

<div  class='col-12'>
<h2>Footer</h2>
<h4>Sub Footer</h4></div>
</div>


<?
echo "<div  style='background: black;color:white;padding:12px;' class='row'>";
echo "<div  class='col-4'>";
$sizesx = 9;
$stylex = 'liststy';
$listx = 'ul';
$clax = 'list-unstyled';
$contx = array("Eastern Cape", "Free State", "Gauteng", "KwaZulu-Natal", "Limpop", "Mpumalanga", "Northern Cape", "North West");
$optstylex = array('tt1', 'tt2', 'tt3', 'tt4', 'tt5', 'tt6');
$lisx = blist($stylex, $listx, $clax, $sizex, $contx, $optstylex);
echo $lisx; 
?>





</div>
<div  class='col-4'>xx</div>
<div  class='col-4'>qq</div>
</div>

<div  style='background: black;color:white;' class='row text-center'>

<div  class='col-12'>
<p class='m-0 text-center text-white'>Copyright &copy; Public Service Internship Club 2018</p><p style='text-align:center;'><i class='fab fa-twitter fa-1x' style='color:#d9534f;'></i><i class=fab fa-instagram fa-1x' style='color:#d9534f;'></i><i class='fab fa-facebook-f fa-1x' style='color:#d9534f;'></i></p><p><img height='30px' src='vm.png' /></p>
</div>

</div>


</div><!container>

<?
require "bootstrapbottom.php";
?>