<? session_start();
require "bootstraptop.php";
require "functions/bootlib.php";

require "header.php";

if(isset($_SESSION[customer]) ) { 
echo "<div class='container-fluid'><div class='row'>
<div style='border-bottom:solid 1px red;'class='col-12 text-center'><h2>Account Details</h2>";

$style = 'liststy';
$list = 'ul';
$cla = 'list-unstyled';
$cont = array("<a href='viewsubscription.php'>My Suscription</a>", "<a href='viewworkshops.php'>My Courses</a>", "<a href='plannedevents.php'>Upcoming Meet Ups</a>", 'Messages', 'Notifications', "<a href='ord1.php'>Orders UnChecked Out</a>", "<a href='ord2.php'>Orders CheckedOut Unpaid</a>", "<a href='ord3.php'>Orders Paid</a>", "<a href='changeps.php'>Change Password</a>", "<a href='logout.php'>Logout</a>", "<a href='custde.php'>Account Details</a>");
$optstyle = array('tt1', 'tt2', 'tt3', 'tt4', 'tt5', 'tt6');
$lis = blist($style, $list, $cla, $size, $cont, $optstyle);
echo $lis;





echo "</div></div><!container>"; } else { echo "<a href='login.php'>Please Login</a>"; } 


require "bootstrapbottom.php";
?>