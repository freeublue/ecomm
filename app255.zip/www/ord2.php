<?
session_start();

require "bootstraptop.php";
require "functions/bootlib.php";
require "../confad.php";
require "../lib.php";

require "header.php";

if(isset($_SESSION[customer]) ) {  
$customer = cr($stp, ($_SESSION[customer]), $action = 'enc');

$sqlc = $db->query("SELECT * FROM cust1 WHERE cu_phone_mobile = '$customer'");
while($row = $sqlc->fetchArray(SQLITE3_ASSOC) ) { 
$newcustid = $row[cu_id]; } 
?>
<div class='container-fluid'>
<?
echo "<div class='row'><div class='col-12'>";
echo "<h4>Unpaid Orders</h4>";
echo "<table width='100%' class='table-striped'><tr><td>OrderNumber</td><td>Product</td><td>Price</td></tr>";
$sq = $db->query("SELECT * FROM wsorders WHERE wo_clientid = '$newcustid' AND wo_orderstatus='2'");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 
$tot[] = $row[wo_price];

$id = $row[wo_ordernum];
$client = $row[wo_clientid];
$product = $row[wo_producttype];
$price = $row[wo_price];
$date = $row[wo_orderdate];
$ordertime = $row[wo_ordertime];
$discounttype = $row[wo_discounttype];
$discountamount = $row[wo_discountamount];
$features = $row[wo_orderfeatures];
$status = $row[wo_orderstatus];
$paytype = $row[wo_paymenttype];
$paystatus = $row[wo_paymentstatus]; 

echo "<tr><td>$id</td><td>$product</td><td>$price</td></tr>";




} 


$total = array_sum($tot);



        echo "<tr><td colspan='5'></td><td>R $total</td></tr></table><br>";
echo "<a href='cartdets.php' class='btn btn-dark'>Make a Payment</a><br>";
echo "You have sucessfully ordered the workshops listed above.</div></div>";
?>




<? } 

else { echo "You must be logged in to proceed"; } 
require "footer.php";
?>




</div><!container>

<?
require "bootstrapbottom.php";
?>