
<?
require "../functions/libsql.php";
$connection = "../../confadmin.php";
$tb = "psts";
$idfield = "bl_id";
$fieldsarray = array("ps_date" , "ps_link", "ps_title", "ps_descps", "ps_txt", "ps_clientid", "ps_img", "ps_cate");
maketb($connection, $tb, $idfield, $fieldsarray);
?>