
<?
require "../functions/libsql.php";
$connection = "../../confadmin.php";
$tb = "ordval";
$idfield = "ov_id";
$fieldsarray = array("ordnum" , "res");
maketb($connection, $tb, $idfield, $fieldsarray);
?>