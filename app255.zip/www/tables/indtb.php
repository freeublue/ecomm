
<?
include "../../confadmin.php";
   $sql =<<<EOF
      CREATE TABLE indtb
      (ind_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,

ind_title, ind_subhead, ind_txt, ind_adtxt, ind_image


);
EOF;

   $ret = $db->exec($sql);
   if(!$ret){
      echo $db->lastErrorMsg();
   } else {
      echo "Table created successfully\n";
   }
   $db->close();
?>