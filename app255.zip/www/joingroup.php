<?
require "bootstraptop.php";
require "functions/bootlib.php";
require "header.php";
?>

<div class='container-fluid'>


<div class='row'>

 

<div class='col-12 text-center'><h2>Group Details</h2>



</div>


</div><!container>

<?
require "bootstrapbottom.php";
?>