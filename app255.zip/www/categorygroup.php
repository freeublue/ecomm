<?
session_start();
error_reporting(0);
require "bootstraptop.php";
require "functions/bootlib.php";

require "header.php";

$searchTerm = $_REQUEST[searchTerm];
if(!isset($searchTerm) ) { 
$searchTerm = $id; } 
else { 
$searchTerm = $_GET[searchTerm];
} 
?>
<div class='container-fluid'>
<?
require "../confad.php";
$sqlx = $db->query("SELECT * FROM locate");
while($rowx = $sqlx->fetchArray(SQLITE3_ASSOC ) ) { 
$locatearray[] = $rowx[lc_title];
} 
        $stm = "SELECT COUNT(*) FROM groupcl WHERE gr_cateid = '$searchTerm'";
       $res = $db->query($stm);
            while($ro = $res->fetchArray(SQLITE3_ASSOC)) { 
            $records = $ro['COUNT(*)'];
            echo "$records<br>";
            
  }
  
 $recordsperpage = 6;
  
  $url = "categorygroup.php";
  echo "<div class='row'><div class='col-md-12'>";
 require "paging.php";
 echo "<br />";
  include "pagx.php";
  echo "</div></div>";
  echo "<hr>";

echo "<div class='row text-center'>";
$sql = $db->query("SELECT * FROM groupcl WHERE gr_cateid = '$searchTerm' ORDER BY gr_province DESC LIMIT $nu, $recordsperpage");
while($rows = $sql->fetchArray(SQLITE3_ASSOC ) ) { 

$nf = $rows[gr_province];

$wa = $locatearray[$nf-1];

echo "<div class='col-12'><h1 style='font-size:28px;text-align:center;border-bottom:1px solid #ed8a63;padding:4px;'><a href='groupspage.php?id=$rows[gr_id]'>$rows[gr_title]</a></h1><h4>$wa</h4><p>$rows[gr_descp]</p><p><a class='btn btn-sm btn-outline-light' href='grouppage.php' role='button'>Join</a></p></div></div>"; } 
?>





<?
require "footer.php";
?>


</div><!container>

<?
require "bootstrapbottom.php";
?>