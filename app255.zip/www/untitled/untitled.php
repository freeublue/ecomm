<?
session_start();
require "bootstraptop.php";
require "functions/bootlib.php";
require "../confad.php";

?>
<style>

#conf1{padding:10px;
color:;
background:; 
border-radius:0px 30px 30px 0px;}
#confirm{background:;}

#conf2{padding:10px;
color:;
background:;
border-right:1px solid #ceb7a2;
border-radius:0px 30px 30px 0px;}
#conf3{padding:10px;
color:;
background:#eee7e0;
border-right:1px solid #ceb7a2;
border-radius:0px 30px 30px 0px; }
</style>


<?
$size = 'xl';
$bootcolor = 'light';
$bootcolor2 = 'light';
$navname = 'Public Service Internship Club';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Categories >>', 'categories.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);
echo "<div class='container-fluid'>";


require "../lib.php";
if (isset($_REQUEST[payid] ) ) { 
$numnew = $_REQUEST[payid];

$id = "confirm";
$size = 3;
$rule = 'text-center';
$colsize = 'col-4';
$gg = array('conf1', 'conf2', 'conf3');
$contentarray[0] = "<h5>Confirm >></h5>";
$contentarray[1] = "<h5>Payment >></h5>";
$contentarray[2] = "<h5>Notification >></h5>";
rowcol($id, $rule, $size, $contentarray, $colsize, $gg);
echo "<div class='row'><div class='col-12'>";
echo "<h4>Payment has been made sucessfully</h4>";
echo "<table><tr><td>OrderNumber</td><td>Product</td><td>Price</td></tr>";
$sq = $db->query("SELECT * FROM wsorders WHERE wo_clientid = '$newcustid' AND wo_ordernum = '$numnew'");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 
$tot = $row[wo_price] - (row[wo_price] * ($row[wo_discountamount]/100));

$id = $row[wo_ordernum];
$client = $row[wo_clientid];
$product = $row[wo_producttype];
$price = $row[wo_price];
$date = $row[wo_orderdate];
$ordertime = $row[wo_ordertime];
$discounttype = $row[wo_discounttype];
$discountamount = $row[wo_discountamount];
$features = $row[wo_orderfeatures];
$status = $row[wo_orderstatus];
$paytype = $row[wo_paymenttype];
$paystatus = $row[wo_paymentstatus]; 

echo "<tr><td>$id</td><td>$product</td><td>$price</td></tr>";




} 


            $sq = $db->query("UPDATE wsorders SET wo_orderstatus = '3', wo_paymentstatus = '2' WHERE wo_ordernum = '$numnew'");
            
            $qs = $db->query("DELETE FROM tempord WHERE tm_clientid = '$cl'");




        echo "<tr><td colspan='5'></td><td>R $total</td></tr></table><br>";
echo "<a class='btn btn-dark' href='ypage.php'>View Details</a><br>";
echo "You have sucessfully purchased the workshops listed above. details are available on your account.</div></div>"; } else { 
echo "<a href='login.php'>Please Login</a>"; } 

include "footer.php";
?>



