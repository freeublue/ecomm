<?
session_start();
require "../confad.php";
$id = $_REQUEST[id];
$sql = $db->query("SELECT * FROM groupcl WHERE gr_id = '$id'");
while($rows = $sql->fetchArray(SQLITE3_ASSOC ) ) { 
$ta = $rows[gr_title];
$title = $ta; } 
require "bootstraptop.php";
require "functions/bootlib.php";

require "header.php";

?>
<style>
#details{
padding:4px;
display:none;
position:absolute;
background:;
color:;
margin-top:30px;
z-index:5;


border: 1px solid #eee7e0;}
td{
height:90px;
width:90px;
border:1px dotted #eee7e0;}
.num{ 
color:teal;
margin-left:2px;
margin-top:-34px;
} 
.ap{
color:#ed8a63;
font-size:8px;
}</style>
<div class='container-fluid'>
<?

$sql = $db->query("SELECT * FROM groupcl WHERE gr_id = '$id'");
while($rows = $sql->fetchArray(SQLITE3_ASSOC ) ) { 
$lat = $rows[gr_lat];
$lng = $rows[gr_lng];

echo "<div class='row text-center'>
<div class='col-12'><h1 style='font-size:28px;text-align:center;border-bottom:1px solid #ed8a63;padding:4px;'>$rows[gr_title]</h1><p>$rows[gr_descp]</p>
</div>
</div>"; } 
?>

<div style='margin-top:4em;' class='row text-center'>
<div class='col-12'><h2 style='font-size:28px;text-align:center;border-bottom:1px solid #ed8a63;padding:4px;'>Join This Group</h2><p>Members can Comment in the group and access special....</p><p><a class='btn btn-dark' href='joingroup.php'>Become a Member</a></p>
</div>
</div>

<div style='margin-top:4em;' class='row text-center'>
<div class='col-12'><h2 style='font-size:28px;text-align:center;border-bottom:1px solid #ed8a63;padding:4px;'>Group Mentors</h2><p></p>
</div>
</div>

<div style='margin-top:4em;' class="row text-center">
<?
$sql = $db->query("SELECT * FROM groupmem WHERE gm_gid = '$id'");
while($rows = $sql->fetchArray(SQLITE3_ASSOC ) ) { 
$mentorid[] = $rows[gm_userid];

} 
foreach ($mentorid as $me) { 
$sq = $db->query("SELECT * FROM mentor WHERE mn_id = '$me'");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 


echo "<div class='col-4'><h4>$row[mn_title]</h4><img style='height:150px;width:150px;' src='$row[mn_image]' class='img-fluid rounded-circle' /><h3 style='color:#eee7e0;height:80px;margin-top:1em;border-bottom:#ceb7a2 1px solid;'>" . $row[mn_title] . "'s Background</h3><div style='padding:4px;border-left:1px dotted #eee7e0;border-right:1px dotted #eee7e0;'><p>$row[mn_descp]</p></div></div>"; } } 
?>
</div>







<div style='margin-top:4em;' class='row text-center'>
<div class='col-12'><h2 style='font-size:28px;text-align:center;padding:4px;'>Past Students</h2><p>Read their stories</p>
</div>
</div>
<div style='margin-top:4em;' class="row text-center">
<div class="col-4"><h3>Jean Jones</h3><img style='height:150px;width:150px;' src='face2.jpg' class='img-fluid rounded-circle' /><p style='margin-top:1em;'><button type="button" class="btn btn-outline-dark">Read More</button></p>
</div>
<div class="col-4"><h3>Valarie Manga</h3><img style='height:150px;width:150px;' src='face5.jpg' class='img-fluid rounded-circle' /><p style='margin-top:1em;'><button type="button" class="btn btn-outline-dark">Read More</button></p>
</div>
<div class="col-4"><h3>Valarie Manga</h3><img style='height:150px;width:150px;' src='face4.jpg' class='img-fluid rounded-circle' /><p style='margin-top:1em;'><button type="button" class="btn btn-outline-dark">Read More</button></p>
</div>
</div>



<div style='margin-top:4em;' class="row text-center">
<div class="col-12">
<h4>News and Events.</h4><p><div id='details'>ww<div></p>

    <h2 class="mb-5 font-weight-bold text-center">News and Events</h2>

   </div></div> <!--Grid row-->
   <div class='row'>
   <div class='col-6'>
   <h4>Join the discussion. Become a member</h4>
   <?
   echo "<a class='btn btn-outline-dark' href='addpost.php?groupid=$id'>Add to Dicussion</a>";
   ?>
   </div>
    <div class='col-6'>
   </div>
   </div>
    <div class="row">

        <!--Grid column-->
        <div class="col-md-12 mb-12">
        <?
         function days_in_month($year, $month) {
return round((mktime(0, 0, 0, $month+1, 1, $year) - mktime(0, 0, 0, $month, 1, $year)) / 86400);
} 
$nowmonth = date("Y-m");
$nowm = $nowmonth . '-01';

$y = strtotime($nowm);
$dr = getdate($y);
$g = $dr["mday"];

$yearb = intval($dr["year"]);
$monthb = $dr["mon"];
$fullmonth = $dr["month"];
$das = days_in_month($yearb, $monthb);
$endmonth = $nowmonth . '-' . $das;
echo "$nowm $endmonth<br>";
echo "<h4>$fullmonth $yearb </h4><br />"; 
$daysarray = range(1, $das, 1);
$appointments = range(1, $das, 1);
$wsid = range(1, $das, 1);
$sq = $db->query("SELECT * FROM workshop2 WHERE ws_groupid = '$id' AND ws_datefr BETWEEN '$nowm' AND '$endmonth'");
while($rowz = $sq->fetchArray(SQLITE3_ASSOC)) { 
echo "$rowz[ws_datefr]<br>";
$daselect = substr($rowz[ws_datefr], -2);
echo "$daselect<br>";
if(substr($daselect, 0, 1) == 0 ) { 
$nax = substr($daselect, 0);

$appointments[$nax-1] = $rowz[ws_title];
$wsid[$nax-1] = $rowz[ws_id];
}  else { 
$nax = $daselect; 

$appointments[$nax-1] = "$rowz[ws_timefr] " . " $rowz[ws_title]";
$wsid[$nax-1] = $rowz[ws_id];
} 
} 



echo "<form name='dateForm' method='post' action='datepage.php'><input style='width:30%;' type='month' name='month' /><input style='width:160px;' type='submit' class='btn btn-sm btn-dark' name='submit' value='Select month' /></form>";

        echo "<center><table width='100%'>
        <tr>";
        for($i=0;$i<7;$i++) { 
        if(strlen($appointments[$i]) < 2) { 
        $ff = " "; } else { 
        $ff = $appointments[$i];
         }
        
        echo "<td><div class='num'>$daysarray[$i]</div><div id='$wsid[$i]' onclick='detailsOf(this.id);' class='ap'>$ff</div></td>"; }
        echo "</tr><tr>";
 
        for($i=7;$i<14;$i++) { 
         if(strlen($appointments[$i]) < 3) { 
        $ff = " "; } else { 
        $ff = $appointments[$i];
         }
        echo "<td><div class='num'>$daysarray[$i] </div><div id='$wsid[$i]' onclick='detailsOf(this.id);' class='ap'>$ff</div></td>"; }
        echo "</tr><tr>";
         
        for($i=14;$i<21;$i++) { 
          if(strlen($appointments[$i]) < 3) { 
        $ff = " "; } else { 
        $ff = $appointments[$i];
         }
        echo "<td><div class='num'>$daysarray[$i]  </div><div id='$wsid[$i]' onclick='detailsOf(this.id);' class='ap'>$ff</div></td>"; }
        echo "</tr><tr>";
         for($i=21;$i<28;$i++) { 
        if(strlen($appointments[$i]) < 3) { 
        $ff = " "; } else { 
        $ff = $appointments[$i];
         }
        echo "<td><div class='num'>$daysarray[$i]</div></td>"; }
         
        echo "</tr><tr>";
        for($i=28;$i<$das;$i++) { 
 if(strlen($appointments[$i]) < 3) { 
        $ff = " "; } else { 
        $ff = $appointments[$i];
         }
        echo "<td><div class='num'>$daysarray[$i]</div><div id='$wsid[$i]' onclick='detailsOf(this.id);' class='ap'>$ff</div></td>"; }
                echo"</tr>
        </table></center>";
        ?>



</div>
</div>
    <div class="row">
<!--Grid column-->


        

        <!--Grid column-->
        <div class="col-md-12 mb-12 text-center">

 <!--Excerpt-->
      <?
    echo "<h2>$fullmonth $yearb </h2><br />"; ?>
    <a href="" class="red-text">

        <h6 class="pb-1"><i style='color:;' class="fa fa-heart"></i><strong style='color:;'> Events  </strong></h6>
    </a>


        </div>
        <!--Grid column-->

    </div>
    <!--Grid row-->
    <hr></section>
          
</p>

          
        </div>
      </div>
      </div>
      

<div style='margin-top:5em;' class='row text-center'>

<div style='background: ;border-radius:15%;' class='col-3'><h4 style='color:;padding:8px;'>Sustainability Workshop</h4><p style='color:#ceb7a2;'>Sustainailbility education program</p><p><img ' src='met2.jpg' class='rounded-circle img-fluid' /></p><p><a class="btn btn-sm btn-outline-dark" href="workshop.php" role="button">View</a></p>
</div>
<div style='background: ;border-radius:15%;' class='col-3'><h4 style='color:;padding:8px;'>Green Energy Workshop</h4><p style='color:#ceb7a2;'>Green Energy discussions and tips.</p><p><img ' src='met4.jpg' class='rounded-circle img-fluid' /></p><p><a class="btn btn-sm btn-outline-dark" href="categories.php" role="button">View</a></p>
</div>
<div style='background: ;border-radius:15%;' class='col-3'><h4 style='color:;padding:8px;'>Energy Save Workshop</h4><p style='color:#ceb7a2;'>Strategies by International gurus.</p><p><img ' src='met1.jpg' class='rounded-circle img-fluid' /></p><p><a class="btn btn-sm btn-outline-dark" href="categories.php" role="button">View</a></p>
</div>
<div style='background: ;border-radius:15%;' class='col-3'><h4 style='color:;padding:8px;'>Solar Grids Workshop</h4><p style='color:#ceb7a2;'>Solar Energy development aids and plans.</p><p><img ' src='met2.jpg' class='rounded-circle img-fluid' /></p><p><a class="btn btn-sm btn-outline-dark" href="categories.php" role="button">View</a></p>
</div>
</div>
      
      </div>
      <script>
var latx = "<?php echo $lat;?>";
var lngx = "<?php echo $lng;?>";
var lat = parseFloat(latx);
var lng = parseFloat(lngx);
</script>

  <div id='container'>
  
 

<div id="map" style="width: 100%; height: 400px; background: grey" />
  <script  type="text/javascript" charset="UTF-8" >
    

function addMarkersToMap(map) {
  var parisMarker = new H.map.Marker({lat:lat, lng:lng});
  map.addObject(parisMarker);


}





/**
 * Boilerplate map initialization code starts below:
 */

//Step 1: initialize communication with the platform
var platform = new H.service.Platform({
   app_id: 'I9Y4iDApiDnRYg4Bcfyx',
  app_code: '8DVGvwPLV6UgKJWVU5-p3A',
  useHTTPS: true
});
var pixelRatio = window.devicePixelRatio || 1;
var defaultLayers = platform.createDefaultLayers({
  tileSize: pixelRatio === 1 ? 256 : 512,
  ppi: pixelRatio === 1 ? undefined : 320
});

//Step 2: initialize a map - this map is centered over Europe
var map = new H.Map(document.getElementById('map'),
  defaultLayers.normal.map,{
  center: {lat:lat, lng:lng},
  zoom: 14,
  pixelRatio: pixelRatio
});

var behavior = new H.mapevents.Behavior(new H.mapevents.MapEvents(map));

// Create the default UI components
var ui = H.ui.UI.createDefault(map, defaultLayers);

// Now use the map as required...
addMarkersToMap(map);
  </script>

   
</div>




<?
require "footer.php";
require "bootstrapbottom.php";
?>


</div><!container>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js" type="text/javascript"></script>
    <script>
    var bb;
    function detailsOf(bb) { 
    
    
$.ajaxSetup({ cache: false }); 
document.getElementById("details").style.display = "block";

var url = "result.php?ele=" + bb;
$('#details').load(url);
    } 
    </script>


<?
?>