<?
$page = $_POST[pagename];
echo "$page<br>";
$cols1 = $_POST[cols0];
echo "$cols1<br>";
$cols2 = $_POST[cols1];
echo "$cols2<br>";