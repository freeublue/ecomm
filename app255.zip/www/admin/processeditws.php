<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?

require "../../confadmin.php";
$tb = "workshop2";
require "../functions/libsql.php";
//groupid addtype img descp equip price fr tfr tto discount discountcr
$groupid = $_POST[groupid];
$title = $_POST[addtype];
$img = $_POST[img];
$descp = $_POST[descp];
$equip = $_POST[equip];
$price = $_POST[price];
$fr = $_POST[fr];
$tfr = $_POST[tfr];
$tto = $_POST[tto];
$discount = $_POST[discount];
$discountcr = $_POST[discountcr];
$subcate = $_POST[subcate];
$status = 1;
$id = $_POST[id];
$fieldsarray = array("ws_groupid", "ws_subcateid", "ws_title", "ws_descp", "ws_image", "ws_price", "ws_equipment", "ws_datefr", "ws_timefr", "ws_timeto", "ws_status", "ws_discount", "ws_discount_criteria");

$fieldsarray2 = array($groupid, $subcate, $title, $descp, $img , $price, $equip, $fr, $tfr, $tto, $status, $discount, $discountcr);
$qs = $db->query("UPDATE workshop2 SET ");
?>
</div></div>
</div></body></html>
