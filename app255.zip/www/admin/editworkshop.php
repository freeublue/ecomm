<?
require "bootstraptop.php";
require "slide.php";
include "../functions/bootlib.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../../lib.php";
include "../../confadmin.php";
echo "<form name='ws' action='processeditws.php' method='post'>";
$id = $_REQUEST[id];
$cate = $_REQUEST[cate];
$group = $_REQUEST[groupid];
echo "$id cate $cate group $group<br>";
$sq = $db->query("SELECT * FROM workshop2 WHERE ws_id = '$id'");
while($ro = $sq->fetchArray(SQLITE3_ASSOC) ) { 
$price =  $ro[ws_price];
$fromdate = $ro[ws_datefr];
$fromtime = $ro[ws_timefr];
$totime = $ro[ws_timeto];
$descp = $ro[ws_descp];
$discount = $ro[ws_discount];
$discountcr = $ro[ws_discount_criteria];
$category = $ro[ws_subcateid];

echo "<label>Add to Group</label><br>";
echo "<select name='subcate'>";
$sql = $db->query("SELECT * FROM subcate WHERE subcate_id = '$category'");
while($rows = $sql->fetchArray(SQLITE3_ASSOC ) ) { 
echo "<option value='$rows[subcate_id]'>$rows[subcate_title] $rows[subcate_gcid]</option>";  } 
echo "</select><br>";
echo "<label>Workshop Name</label><br><input id='addtype' value='$ro[ws_title]' name='addtype' /><label>Workshop Image</label><br>
           <input id='img' name='img' type='text'><br>
           <label>Workshop Motto</label><br>
           <textarea rows='10' cols='10' name='motto'></textarea><br>";
           echo "<label>Workshop Description</label><br>
           <textarea rows='10' cols='30' name='descp'>$descp</textarea><br>";
                   echo "<label>Workshop Equipment</label><br>
           <textarea rows='10' cols='30' name='equip'>$ro[ws_equipment]</textarea><br>";
           
 $input_labelc1 = 'Price';
 $input_typec1 = 'number';
 $sizec1 = 'col-xs-8 col-md-12';
 $input_idc1 = 'price';
 $va1 = $price;
 input_formv($input_idc1, $input_typec1, $input_labelc1, $sizec1, $va1);
            
 $input_labelc12 = 'Date';
 $input_typec12 = 'date';
 $sizec12 = 'col-xs-8 col-md-12';
 $input_idc12 = 'fr';
 $va12 = $fromdate;
 input_formv($input_idc12, $input_typec12, $input_labelc12, $sizec12, $va12);
             
 $input_labelc12 = 'Time From';
 $input_typec12 = 'time';
 $sizec12 = 'col-xs-8 col-md-12';
 $input_idc12 = 'tfr';
 $va12 = $fromtime;
 input_formv($input_idc12, $input_typec12, $input_labelc12, $sizec12, $va12);

  $input_labelc12 = 'Time To';
 $input_typec12 = 'time';
 $sizec12 = 'col-xs-8 col-md-12';
 $input_idc12 = 'tto';
 $va12 = $totime;
 input_formv($input_idc12, $input_typec12, $input_labelc12, $sizec12, $va12);
    
$input_labelc12 = 'Discount as a Percentage';
 $input_typec12 = 'number';
 $sizec12 = 'col-xs-8 col-md-12';
 $input_idc12 = 'discount';
 $va12 = $discount;
 input_formv($input_idc12, $input_typec12, $input_labelc12, $sizec12, $va12);
 $input_labelc12 = 'Discount Criteria';
 $input_typec12 = 'text';
 $sizec12 = 'col-xs-8 col-md-12';
 $input_idc12 = 'discountcr';
 $va12 = 'Subscription';
 input_formv($input_idc12, $input_typec12, $input_labelc12, $sizec12, $va12);
 echo "<input type='text' name='groupid' value='$id' />"; }
           ?>
           
                  <button id='add_em' class='btn btn-primary' type='submit'> 
                     Go! 
                  </button></form>


?>
</div></div>
</div></body></html>
