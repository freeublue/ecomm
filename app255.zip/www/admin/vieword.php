<?
require "bootstraptop.php";
require "slide.php";
include "../../bootlib.php";
include "../../confadmin.php";

?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<h4>Order Details</h4>
</div>
</div>
<div class='row'>
<div class='col-12'>
<?


$id = $_REQUEST["id"];

echo "<table class='table-bordered' width='100%'><tr>
      <td><b>Order ID</b></td>
      <td><b>Order Number</b></td>
      <td><b>Client ID</b></td>
      <td><b>Product Type</b></td>
      <td><b>Product Price</b></td>
      <td><b>Order Date</b></td>
      <td><b>Order Time</b></td>
      <td><b>Order Discount Type</b></td>
      <td><b>Order Discount Amount</b></td>
      <td><b>Order Features</b></td>
      <td><b>Order Status</b></td>
      <td><b>Order Payment Type</b></td>
      <td><b>Order Payment Status</b></td>
   

      </tr><tr>";
$sq = $db->query("SELECT * FROM wsorders WHERE wo_id ='$id'");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 
echo "<td> $row[wo_id]</td>";
echo "<td> $row[wo_ordernum]</td>";
echo "<td> $row[wo_clientid]<a href='viewclient.php?id=$row[wo_clientid]'>View</a></td>";
echo "<td> $row[wo_producttype]</td>";
echo "<td> $row[wo_price]</td>";
echo "<td> $row[wo_orderdate]</td>";
echo "<td> $row[wo_ordertime]</td>";
echo "<td> $row[wo_discounttype]</td>";
echo "<td> $row[wo_discountamount]</td>";
echo "<td> $row[wo_orderfeatures]</td>";
echo "<td> $row[wo_orderstatus]</td>";
echo "<td> $row[wo_paymenttype]</td>";
echo "<td> $row[wo_paymentstatus]</td>";

} 
?></tr></table><br><a href='index.php'>Home</a></br></div></div></div>