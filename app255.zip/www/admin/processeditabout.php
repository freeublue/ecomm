<?
error_reporting(0);
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?

include "../functions/libsql.php";
$tb = "about";
require "../../confadmin.php";
$title = $_POST[addtype];
echo "$title";
if (EMPTY($_POST[addtype]) ) { 
echo "Please enter a title"; } else { 
$title = cl($_POST[addtype]);
$subhead = cl($_POST[subhead]);

$descp = cl($_POST[descp]);

$id = $_POST[id];

$ar = array('png' , 'jpg' , 'gif', 'jpeg');
$fill = strtolower($_FILES['userfile'] ['name']); 
$fil = substr($fil1, -3); 
echo "file $fill sub $fil";
if ($fil != $ar['0'] || $fil != $ar['1'] || $fil != $ar['2'] || $fil != $ar['3']) 
{ 
echo "You have uploaded a file in the wrong formatt, only jpg, gif or png allowed"; 
} 




echo $_FILES['userfile'] ['tmp_name'];
$fileName = $_FILES['userfile'] ['name'];
$tmpName = $_FILES['userfile'] ['tmp_name'];
$fileSize = $_FILES['userfile'] ['size'];
$fp = fopen($tmpName, 'r');
$content = fread($fp, $fileSize);
$content = addslashes($content);
fclose($fp);
$picture = str_replace(' ', '_', $tmpName);


$source = $picture;
$na = time();

$target = '../pic/' . $fileName;
$newname = '../pic/' . $na . '.jpg';
$newna = 'pic/' . $na . '.jpg';

move_uploaded_file($source, $newname );

$newname = 'pic/' . $na . '.jpg';
$wq = rename($target, $newname);
$image = $newname;
echo "File<b> $fileName $picture picture</b> uploaded as id= $id<br>";



echo "File<b> $fileName</b> uploaded<br>";
echo "<b>All images in pic directory gallery</b></br >"; 


$fieldsarray = array("ab_title", "ab_txt", "ab_image", "ab_subhead");
$fieldsarray2 = array($title, $descp, $image, $subhead);

$sv = $db->query("UPDATE about SET ab_title = '$title', ab_image = '$image', ab_txt = '$descp', ab_subhead = '$subhead' WHERE ab_id = '$id'");

 } 
?>
</div></div>
</div></body></html>

