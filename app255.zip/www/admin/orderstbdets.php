<?
include "../../confadmin.php";
$sq = $db->query("SELECT * FROM wsorders");
while($rowz = $sq->fetchArray(SQLITE3_ASSOC)) { 
echo "Order Number $rowz[wo_ordernum]<br>";
echo "Client id $rowz[wo_clientid]<br>"; 
echo "Product $rowz[wo_producttype]<br>"; 
echo "Order date $rowz[wo_orderdate]<br>"; 
echo "Time $rowz[wo_ordertime]<br>";
echo "Price $rowz[wo_price]<br>";
echo "Features $rowz[wo_features]<br>";
echo "Status $rowz[wo_orderstatus]<br>";
echo "Discount $rowz[wo_discountamount]<br>";
echo "Workshop id $rowz[wo_wsid]<br><hr>"; } 
?>
wo_ordernum", "wo_clientid", "wo_wsid", "wo_groupid", "wo_producttype", "wo_price", "wo_quanity", "wo_subscribtiontype", "wo_orderdate", "wo_ordertime", "wo_discounttype", "wo_discountamount", "wo_orderfeatures", "wo_orderaddress", "wo_orderstatus", "wo_paymenttype", "wo_paymentstatus", "wo_paymentamount", "wo_notes
wsorders
wo_id
ordnum
od_id
od_num