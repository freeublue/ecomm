<?
error_reporting(0);
$address = trim($_REQUEST[nam]);
echo "Adress $address";
$newad = str_replace('_', '+', $address);

echo "$newad<br>";
$w = file_get_contents("https://geocoder.api.here.com/6.2/geocode.xml?app_id=aOZ0gFA9M1Q3OwAeU90E&app_code=HV1Z1K2sggmrpFEXUg9Wtg&searchtext=$newad");
$file = "coord.xml";
$fp = fopen($file, "w");
fwrite($fp, $w);
$xml=simplexml_load_file("coord.xml");

foreach($xml->Response as $xx) { 

$view = $xx->View->Result->Location->DisplayPosition->Latitude;
echo "<b>Latitude: </b> $view<br>";
$view2 = $xx->View->Result->Location->DisplayPosition->Longitude;
echo "<b>Longitude: </b> $view2<br>";
  
 
      
   } 


?>
