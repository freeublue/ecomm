<?
$q[11] = 3000;
$q[12] = 5000;
$tota = 8000;
for($i=1;$i<13;$i++) { 
$m[$i] = ($q[$i]/$tota) * 100; } 
echo $m[12];
foreach($m as $r) { 
$p[] = ceil($r);

} 

?>


