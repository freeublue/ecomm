dc_date" , "dc_link", "dc_title", "dc_descps", "dc_txt", "dc_vid", "dc_img", "dc_cate"
<?
require "../../functions/libsql.php";

$date = $_POST[date];
$connection = "../../../confdocs.php";
$tb = "docs";

$descps = cl($_POST[descps]);
$link = $_POST[link];
$title = cl($_POST[title]);
$txt = cl($_POST[txt]);
$vid = $_POST[vid];
$cate = $_POST[cate];
$cate1 = $_POST[cate1];
echo $_FILES['userfile'] ['tmp_name'];
$fileName = $_FILES['userfile'] ['name'];
$tmpName = $_FILES['userfile'] ['tmp_name'];
$fileSize = $_FILES['userfile'] ['size'];
$fp = fopen($tmpName, 'r');
$content = fread($fp, $fileSize);
$content = addslashes($content);
fclose($fp);
$picture = str_replace(' ', '_', $tmpName);
$source = $picture;
$target = '../../pic/' . $fileName;
move_uploaded_file($source, $target );
$image = $target;
echo "File<b> $fileName</b> uploaded as id= $id<br>";



echo "File<b> $fileName</b> uploaded<br>";
echo "<b>All images in pic directory gallery</b></br >"; 
echo "<b><a href='index.php'>Return Home</a></b></br >"; 




$fieldsarray = array("dc_date" , "dc_link", "dc_title", "dc_descps", "dc_txt", "dc_vid", "dc_img", "dc_cate");
$fieldsarray2 = array($date, $link, $title, $descps, $txt, $vid, $image, $cate);

instb($connection, $tb, $fieldsarray, $fieldsarray2); 
?>
