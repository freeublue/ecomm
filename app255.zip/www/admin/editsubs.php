<?
require "../bootstraptop.php";
require "slide.php";
?>
<style>
#results{ 
display:none;

} </style>
<div class='container'>
<div class='row'>
<div style='height:800px;' class='col-6'>
<?
include "../../lib.php";
include "../../confadmin.php";
$id = $_REQUEST[ty];
$sql = $db->query("SELECT * FROM subscription WHERE sb_id = '$id'");
while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 
echo "<form action='processeditsub.php' method='post'>";
echo "<h4>Enter Subscription</h4><p>Enter features as a comma seperated list in description. </p><br />";
  echo "<p><input id='addtitle' name='addtitle' value='$row[sb_title]' placeholder='Title' type='text'></p><br>";
    echo "<p><textarea cols='40' rows='20' id='adddescp' name='adddescp'  placeholder='Comma seperated list of features'>$row[sb_descp]</textarea></p><br>";
      echo "<p><input id='addimage' name='addimage' value='$row[sb_image]' placeholder='Image .jpg or .png icon 200px by 200px' type='text'></p><br>";
        echo "<p><input id='addprice' placeholder='Price' value='$row[sb_price]' name='addprice' type='text'></p><br>";
  echo "<p><select name='addstatus' id='addstatus'>$row[sb_status]'
  <option value='active'>Active</option>
  <option value='inactive'>In Active</option>
  </select>
  </p><br>";
           echo "<input id='addrepeat' name='addrepeat' value='$row[sb_repeat]' placeholder='Regularity' type='text'><br><p><input type='hidden' name='id' value='$id' /><button id='add_em' class='btn btn-primary' type='submit'> 
                     Go! 
                  </button></form></p><p><div id='resultsp'>gg</div></p>"; } 


?>
</div>
<div class='col-6'>

<?php
echo "<h4>Edit Subscription</h4><p>Features are a comma separated list in description field. </p><br />";

?>

</div>
</div>





