<?php 
$endereco = "Rua Canapi 193, Guarulhos, Sao Paulo, Brasil";
$id = "here_id";
$cod = "here_cod";

$json = json_decode ( file_get_contents ( "https://geocoder.api.here.com/6.2/geocode.json?app_id=" . urlencode ( $id) . "&app_code=" . urlencode ( $cod) . "&searchtext=" . urlencode ( $endereco)), true);

echo "Longitude: " . $json["Response"]["View"][0]["Result"][0]["Location"]["DisplayPosition"]["Longitude"] . "<br />";
echo "Latitude: " . $json["Response"]["View"][0]["Result"][0]["Location"]["DisplayPosition"]["Latitude"] . "<br />";

echo "<pre>";
print_r ( $json);
echo "</pre>";
?>