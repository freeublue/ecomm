
<form name='workform' method='post' action='processblog.php'>
<h2>Blog Post</h2>
<label>Date</label><br>
<input type='date' name='date' /><br>
<label>Link</label><br>
<input type='text' name='link' /><br>
<label>Title</label><br>
<input type='text' name='title' /><br>
<label>Description</label><br>
<input type='text' name='descps' /><br>
<label>Text</label><br>
<textarea name ='txt' rows='50' cols='50'></textarea><br>

<label>Byline</label><br>
<input type='text' name='byline' /><br>
<label>External Link 1</label><br>
<input type='text' name='extlink1' /><br>
<label>External Link 2</label><br>
<input type='text' name='extlink2' /><br>
<label>External Link 3</label><br>
<input type='text' name='extlink3' /><br>
<label>External Link 4</label><br>
<input type='text' name='extlink4' /><br>
<label>External Link 5</label><br>
<input type='text' name='extlink5' /><br>
<label>External Link 1</label><br>
<input type='text' name='extlinkdescp1' /><br>
<label>External Link 2</label><br>
<input type='text' name='extlinkdescp2' /><br>
<label>External Link 3</label><br>
<input type='text' name='extlinkdescp3' /><br>
<label>External Link 4</label><br>
<input type='text' name='extlinkdescp4' /><br>
<label>External Link 5</label><br>
<input type='text' name='extlinkdescp5' /><br>
<label>Category 1</label><br>

<?
require "../confbp.php";
echo "<select name='cate'>";
$sq = $db->query("SELECT * FROM cate");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) {

echo "<option value='$row[id]'>$row[cate_title]</option><br>";


} 
echo "</select><br>";
echo "<label>Category 2</label><br>";
echo "<select name='cate1'>";
$sq = $db->query("SELECT * FROM cate");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) {

echo "<option value='$row[id]'>$row[cate_title]</option><br>";


} 
echo "</select><br>";
echo "<label>Category 3</label><br>";
echo "<select name='cate2'>";
$sq = $db->query("SELECT * FROM cate");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) {

echo "<option value='$row[id]'>$row[cate_title]</option><br>";


} 
echo "</select><br>";
?>
<input type='submit' value='submit' name='submit' /></form>

