<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-6'>
<?
include "../../lib.php";
include "../../confadmin.php";

echo "<form action='processsubcate.php' method='post'>";
echo "<h4>Enter SubType</h4><p>Types serve as categories. Each product may be inserted into one matching category. </p><br /><select name='cate'>";
$sql = $db->query("SELECT * FROM groupcate");
while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 

echo "<option value='$row[gc_id]'>$row[gc_title] $row[gc_id]</option>"; } 
echo "</select>";
 

           echo "<label>Sub-category Name</label><input id='addtype' name='addtype' type='text'><br><label>SubCategory Image</label>
           <input id='img' name='img' type='text'><br>
           <label>SubCategory Description</label>
           <textarea rows='10' cols='30' name='descp'></textarea><br>
               
                  <button id='add_em' class='btn btn-primary' type='submit'> 
                     Go! 
                  </button></form><p><div id='results'>gg</div></p>"; 


?>
</div>
<div class='col-6'>

<?php
echo "<h4>Edit Type</h4><p>SubTypes serve as categories for workshops. </p><br />";
$sql = $db->query("SELECT * FROM subcate LIMIT 0, 30 ");
while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 

echo "<a href='editsubcate.php?ty=$row[subcate_id]'>edit $row[sub_title] $row[subcate_id]</a>|<a href='deletesubcate.php?ty=$row[subcate_id]'>delete $row[subcate_title]</a><br />"; } 
?>

</div>
</div>


</div></div>
</div></body></html>