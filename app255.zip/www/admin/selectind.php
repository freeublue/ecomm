<table width='800px' border=1><tr><td width='500px' valign='top'>
<?php
include "../../confadmin.php";
require "../../lib.php";
$sql = $db->query("SELECT * FROM indtb");


while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 


echo "$row[ind_title]<br />";
echo "$row[ind_subhead]<br />";
echo "$row[ind_image]<br />";
echo "$row[ind_txt]<br />"; } 
?>
</td><td width='100px' valign='top'><a href='index.php'>Home</a></td></tr></table>
