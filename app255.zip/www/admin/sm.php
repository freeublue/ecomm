<?php 

$address = trim($_REQUEST[nam]);
echo "Adress $address";
$newad = str_replace('_', '+', $address);

echo "$newad";
$json = json_decode ( file_get_contents ( "https://geocoder.api.here.com/6.2/geocode.json?app_id=aOZ0gFA9M1Q3OwAeU90E&app_code=HV1Z1K2sggmrpFEXUg9Wtg&searchtext=" . urlencode ( $newad)), true);

echo "Longitude: " . $json["Response"]["View"][0]["Result"][0]["Location"]["DisplayPosition"]["Longitude"] . "<br />";
echo "Latitude: " . $json["Response"]["View"][0]["Result"][0]["Location"]["DisplayPosition"]["Latitude"] . "<br />";


?>