     <?
     require "bootstraptop.php";
     ?>
     <div class='row'>
     <div class='col-12'>
      
          <i class="fa fa-table"></i>Users</div>
        
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Mobile</th>
                  <th>Email</th>
                  
                  <th>Start Date</th>
                  
                </tr>
              </thead>
              <tfoot>
                <tr>
                  <th>Name</th>
                  <th>Mobile</th>
                  <th>Email</th>
                  
                  <th>Start Date</th>
                  
                </tr>
              </tfoot>
              <tbody>
              <?php
              require "../../confadmin.php";
              require "../../lib.php";
              
       $stmt = $db->query("SELECT * FROM cust1");
while ($row = $stmt->fetchArray(SQLITE3_ASSOC)) {
    
$now = date("Y-m-d");
$phone = cr($stp, $row[cu_phone_mobile], $action = 'ivg');
$email = cr($stp, $row[cu_email], $action = 'ivg');



            echo "<tr>";
            
               echo "<td>" . $row["cu_fname"]. ' ' . $row["cu_lname"] . "</td>";
               
               echo "<td>" . $phone . "</td>"; 
               echo "<td>" . $email . "<br><a href='message.php?id=$row[cu_id]'>Message</a><br><a href='mail.php?id=$row[cu_id]'>Email</a></td><td>" . $row["cu_dayfirst"] . "</td>"; 
               echo "</tr>";
               

               } 
               ?>
              
             
              </tbody>
            </table>
            </div>
            </div>
          
    
    
<script>
$(document).ready(function() {
    $('#dataTable').DataTable();
} );
</script>
    
  </div>