<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-6'>
<?
include "../../lib.php";
include "../../confadmin.php";
$id = $_REQUEST[ty];
$sql = $db->query("SELECT * FROM locate WHERE lc_id = '$id'");
while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 
echo "<form action='processeditlocate.php' method='post'>";
echo "<h4>Enter Locations</h4>";
 

           echo "<label>Location Name</label><input id='title' name='title' value='$row[lc_title]' type='text'><br><label>Location Latitude</label>
           <input id='lat' name='lat' value='$row[lc_lat]' type='text'><br>
           <label>Location Longtitude</label>
           <input id='lng' name='lng' value='$row[lc_lng]' type='text'><br>
           <input id='id' name='id' value='$row[lc_id]' type='text'>

               
                  <button id='add_em' class='btn btn-primary' type='submit'> 
                     Go! 
                  </button></form<p><div id='results'>gg</div></p>"; } 


?>
</div>
<div class='col-6'>

<?php
echo "<h4>Edit Type</h4><p>SubTypes serve as categories for workshops. </p><br />";
$sql = $db->query("SELECT * FROM locate LIMIT 0, 30 ");
while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 

echo "<a href='editlocate.php?ty=$row[lc_id]'>edit $row[lc_title] $row[lc_id]</a>|<a href='deletelocate.php?ty=$row[lc_id]'>delete $row[lc_title]</a><br />"; } 
?>

</div>
</div>


</div></div>
</div></body></html>
lc_title, lc_lat, lc_lng
Eastern Cape -32.0000 27.0000
Free State -28.45411 26.79678
Gauteng -26.27076 28.11227
KwaZulu-Natal -30.94717 29.25823
Limpopo -23.40129 29.41793
Mpumalanga -25.56534 30.52791
Northern Cape -29.04668 21.85686
North West -26.66386 25.28376
Western Cape