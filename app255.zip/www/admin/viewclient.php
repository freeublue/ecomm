<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../../lib.php";
include "../../confadmin.php";
$id = $_REQUEST[id];

echo "<table class='table-bordered' width='100%'><tr>
      <td><b>First Name</b></td>
      <td><b>Last Name</b></td>
      <td><b>Contact Title</b></td>
      <td><b>Email</b></td>
      <td><b>Mobile</b></td>
      <td><b>Subscription Status</b></td>
     
   

      </tr><tr>";
$sq = $db->query("SELECT * FROM cust1 WHERE cu_id = '$id'");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 
$phone = cr($stp, $row[cu_phone_mobile], $action = 'ivg');
$em = cr($stp, $row[cu_email], $action = 'ivg');

echo "<td> $row[cu_fname]</td>";
echo "<td> $row[cu_lname]</td>";
echo "<td> $row[cu_contact_title]</td>";
echo "<td> $em</td>";
echo "<td> $phone</td>";
echo "<td> $row[cu_subscriptionstatus]</td>";
} 
?><tr></table>
</div></div>
</div></body></html>
