<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
error_reporting(0);
include "../functions/libsql.php";
$tb = "indtb";
$connection = "../../confadmin.php";
$title = $_POST[addtype];
echo "$title";
if (EMPTY($_POST[addtype]) ) { 
echo "Please enter a title"; } else { 
$title = cl($_POST[addtype]);
$subhead = cl($_POST[subhead]);
$image = $_POST[img];
$descp = cl($_POST[descp]);



$fieldsarray = array("ind_title", "ind_txt", "ind_image", "ind_subhead");
$fieldsarray2 = array($title, $descp, $image, $subhead);

instb($connection, $tb, $fieldsarray, $fieldsarray2);

 } 
?>
</div></div>
</div></body></html>

