<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../../lib.php";
include "../../confadmin.php";
$id = $_REQUEST[id];
$sq = $db->query("SELECT * FROM mentor WHERE mn_id = '$id'");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 

           echo "<form action='processeditmentor.php' enctype='multipart/form-data'method='post'><label>Name</label><br><input id='addtype' value='$row[mn_title]' name='addtype' /><label>Profile Image <img src='$row[mn_image]' height='150px' /></label><br><input type='hidden' name='MAX_FILE_SIZE' value='30000000' /><input name='userfile' type='file' id='userfile' />
           <br>
           <label>Short Personal Description</label><br>
           <textarea rows='10' cols='30' name='descp'>$row[mn_descp]</textarea><br>";
   echo "<label>Skill Set</label><br>
           <textarea rows='10' cols='30' name='skills'>$row[mn_skills]</textarea><br>";
   echo "<label>Education/Schools/University</label><br>
           <textarea rows='10' cols='30' name='edu'>$row[mn_education]</textarea><br>";
           echo "<input type='text' name='id' value='$id' /><br>";

                  echo "<button id='add_em' class='btn btn-danger' type='submit'> 
                     Go! 
                  </button>";
echo "</form>"; } 
?>
</div></div>
<div class='row'>
<div class='col-12'>


</div></div>
</div></body></html>
mn_title, mn_descp, mn_image, mn_vid, mn_skills, mn_education
addtype img descp skills edu