<?
$tmpName = 'drdrtytr ewwe-4 dddd.jpeg';
$picture = str_replace(' ', '_', $tmpName);
$na = time();
$subpic = substr($picture, -3);
if($subpic == 'jpg' || $subpic == 'png' || $subpic == 'gif') { 
$pi = substr($picture, 0, -4); } else { 
$pi = substr($picture, 0, -5); } 
$picture = str_replace($pi, $na, $picture);
echo "$picture";