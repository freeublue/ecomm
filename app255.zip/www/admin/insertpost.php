
<form name='workform' method='post' action='process.php'>
<h2>Blog Post</h2>
<label>Date</label><br>
<input type='date' name='date' /><br>
<label>Link</label><br>
<input type='text' name='link' /><br>
<label>Title</label><br>
<input type='text' name='title' /><br>
<label>Description</label><br>
<input type='text' name='descps' /><br>
<label>Text</label><br>
<textarea name ='txt' rows='50' cols='50'></textarea><br>

<label>Byline</label><br>
<input type='text' name='byline' /><br>

<label>Category </label><br>

<?
require "../confbp.php";
echo "<select name='cate'>";
$sq = $db->query("SELECT * FROM cate");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) {

echo "<option value='$row[id]'>$row[cate_title]</option><br>";


} 
echo "</select><br>";

?>
<input type='submit' value='submit' name='submit' /></form>

