<?
require "../../confadmin.php";
$ptype = $_REQUEST[ty];
echo "$ptype deleted sucessfully <a href='addcategory.php'>Go back</a><br>";
$db->exec("DELETE FROM groupcate WHERE gc_id = '$ptype'");