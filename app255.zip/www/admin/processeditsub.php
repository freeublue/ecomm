<?
require "../bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../../lib.php";
include "../../confadmin.php";
$sb_title = $_POST[addtitle];
$sb_descp = $_POST[adddescp];
$sb_image = $_POST[addimage];
$sb_price = $_POST[addprice];
$sb_status = $_POST[addstatus];
$sb_repeat = $_POST[addrepeat];
$id = $_POST[id];
echo "<ul>
<li>$sb_title</li>
<li>$sb_descp</li>
<li>$sb_image</li>
<li>$sb_price</li>
<li>$sb_status</li>
<li>$sb_repeat</li>
</ul>";
$sq = $db->query("UPDATE subscription SET sb_title = '$sb_title', sb_descp = '$sb_descp', sb_image = '$sb_image', sb_price = '$sb_price', sb_status = '$sb_status' , sb_repeat = '$sb_repeat' WHERE sb_id = '$id' ");
echo "Data updated <a href='index.php'>Return Home</a>";

?>
</div></div>
</div></body></html>