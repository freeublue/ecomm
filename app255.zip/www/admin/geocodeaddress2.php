<?

$address = trim($_REQUEST[nam]);
echo "Adress $address";
$newad = str_replace('_', '+', $address);

echo "$newad";
$w = file_get_contents("https://geocoder.api.here.com/6.2/geocode.xml?app_id=aOZ0gFA9M1Q3OwAeU90E&app_code=HV1Z1K2sggmrpFEXUg9Wtg&searchtext=$newad");
$file = "coord.xml";
$fp = fopen($file, "w");
fwrite($fp, $w);

$y = file_get_contents($file);
$x = strpos($y, "<DisplayPosition>");
$n = strpos($y, "</DisplayPosition>");
$lenght = strlen($y);
$num = $n - $x;
$str1 = substr($y, $x, $num);
echo "$str1<br>";


$la = str_replace('<Latitude>', " ", $str1);
$lap = str_replace('</Latitude>', " ", $la);
$lam = strpos($lap, '<Longitude>');
$last = strpos($lap, '</Longitude>');
$fin = ($lam+11);
$lat1 = substr($lap, 0, $lam);
$lon1 = substr($lap, $fin, $last);
$lat = trim(str_replace("<DisplayPosition>", " ", $lat1) );
$lon = trim(str_replace("</Longitude>", " ", $lon1) );
echo "<h4>Latitude :</h4>" . $lat . "<br>";
echo "<h4>Longitude :</h4>" . $lon . "<br>"; 
?>
