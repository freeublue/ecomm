
<?
require "bootstraptop.php";
require "slide.php";
require "../functions/libsql.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?

$tb = "locate";
require "../../confadmin.php";
if (EMPTY($_POST[title]) ) { 
echo "Please enter a title"; } else { 

$title = $_POST[title];
$lat = $_POST[lat];
$lng = $_POST[lng];
echo " title $title lat $lat lng $lng";
$id = $_POST[id];
$fieldsarray = array("lc_title", "lc_lat", "lc_lng");
$fieldsarray2 = array($title, $lat, $lng);

$sq = $db->query("UPDATE locate SET lc_title = '$title', lc_lat = '$lat', lc_lng = '$lng' WHERE lc_id = '$id'"); } 
?>
</div></div>
</div></body></html>