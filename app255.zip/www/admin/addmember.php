<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../../lib.php";
include "../../confadmin.php";
$id = $_REQUEST[id];
$cate = $_REQUEST[cate];
echo "$id $cate<br>";
echo "<form action='processmember.php' method='post'>";
echo "<br><label>Add user roles</label><br>";
echo "<select name='gm_userid'>";
$sq = $db->query("SELECT * FROM mentor");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 
echo "<option value='$row[mn_id]'>$row[mn_title]</option>";
} 
echo "</select>";
echo "<br><label>Role</label><br>";
echo "<select name='gm_role'>";
echo "<option value='mentor'>Mentor</option>";
echo "<option value='admin'>Admin</option>";
echo "<option value='student'>Student</option>";
echo "</select><br>";
echo "<br><label>Group ID</label>";
echo "<input type='text' value='$id' name='gm_gid' /><br>";
echo "<br><label>Status</label><br>";
echo "<select name='gm_status'>";
echo "<option value='active'>Active</option>";
echo "<option value='inactive'>Inactive</option>";
echo "<option value='warned'>Warned</option>";
echo "<option value='rmv'>RMV</option>";

echo "</select><br>";
?>
                  <button id='add_em' class='btn btn-primary' type='submit'> 
                     Go! 
                  </button></form>

</div></div>
</div></body></html>
