<?
require "bootstraptop.php";
require "slide.php";
?>
<style>
#results{ 
display:none;

} </style>
<div class='container'>
<div class='row'>
<div class='col-6'>
<?
include "../../lib.php";
include "../../confadmin.php";

echo "<form>";
echo "<h4>Enter Type</h4><p>Types serve as categories. Each product may be inserted into three matching categories. </p><br />";

           echo "<input id='addtype' name='addtype' type='text'> 
               
                  <button id='add_em' class='btn btn-primary' type='button'> 
                     Go! 
                  </button></form<p><div id='results'>gg</div></p>"; 


?>
</div>
<div class='col-6'>

<?php
echo "<h4>Edit Type</h4><p>Types serve as categories. Each product may be inserted into three matching categories. </p><br />";
$sql = $db->query("SELECT * FROM groupcate LIMIT 0, 30 ");
while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 

echo "<a href='editty.php?ty=$row[gc_id]'>edit $row[gc_title] $row[gc_id]</a>|<a href='deletetype.php?ty=$row[gc_id]'>delete $row[gc_title]</a><br />"; } 
?>

</div>
</div>


<div class='row'>
<div class='col-6'>
<?


echo "<form>";
echo "<h4>Enter Brand</h4><p>Data for your brands serve as brand names. </p><br />";

           echo "
               <input id='addbrand' name='addtype' type='text'> 
               
                  <button id='add_it' class='btn btn-primary' type='button'> 
                     Go! 
                  </button></form<p><div id='resultsx'>gg</div></p>"; 


?>
</div>
<div class='col-6'>

<?php
echo "<h4>Edit Brands</h4><p>Brands. </p><br />";
$sql = $db->query("SELECT * FROM brand LIMIT 0, 30 ");
while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 

echo "<a href='editbrand.php?id=$row[br_id]'>edit $row[br_title] $row[ty_id]</a>|<a href='deletebrand.php?id=$row[br_id]'>delete $row[br_title]</a><br />"; } 
?>

</div>
</div>







<div class='row'>
<div class='col-6'>
<?



echo "<h4>Enter Payment Option</h4><p>Payment Options such as Cash, EFT, External payment gateway(we offer Payfast and Paypal). </p><br />";

           echo "<form name='payform'><div class='checkbox'> 
   <label><input type='checkbox' value='PayFast'>PayFast</label> 
</div> 
<div class='checkbox'> 
   <label><input type='checkbox' value='PayPal'>PayPal</label> 
</div> 
<div class='checkbox'> 
   <label><input type='checkbox' value='Cash'>Cash</label> 
</div>
 <div class='checkbox'> 
   <label><input type='checkbox' value='EFT'>EFT</label> 
</div>  
<div class='checkbox'> 
   <label><input type='checkbox' value='COD'>COD</label> 
</div>
<div class='checkbox'> 
   <label><input type='checkbox' value='Cash_on_Collection'>Cash on Collection</label> 
</div>

              <button id='add_pay' class='btn btn-primary' type='button'> 
                     Go! 
                  </button></form>
 
<p><div id='resultsp'>gg</div></p>"; 


?>
</div>
<div class='col-6'>

<?php
echo "<h4>Edit Payment Options</h4><p>Payment. </p><br />";
$sql = $db->query("SELECT * FROM paytypes LIMIT 0, 30 ");
while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 

echo "<a href='editbrand.php?id=$row[pt_id]'>edit $row[pt_title] $row[ty_id]</a>|<a href='deletebrand.php?id=$row[pt_id]'>delete $row[pt_title]</a><br />"; } 
?>

</div>
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js" type="text/javascript"></script>
<script>
$(document).ready(function(){ 

$("#results").slideUp(); 

    $("#add_em").click(function(e){ 
        e.preventDefault(); 

        ajax_sear(); 
    }); 
     
$("#resultsx").slideUp();
$("#add_it").click(function(e) { 
        e.preventDefault(); 

        ajax_se(); 
});

$("#resultsp").slideUp();
$("#add_pay").click(function(e) { 
        e.preventDefault(); 

        ajax_sepay(); 
});

}); 


function ajax_sear(){ 

  $("#results").show(); 
  
var typename = $("#addtype").val();


  $.post("processtype.php", {type : typename }, function(data){
   if (data.length>0){ 

   $("#results").html(data); 
   } 
  }) 
} 

function ajax_se(){ 

  $("#resultsx").show(); 
  
var brandname = $("#addbrand").val();


  $.post("processbrand.php", {brand : brandname }, function(data){
   if (data.length>0){ 

   $("#resultsx").html(data); 
   } 
  }) 
}
function ajax_sepay(){ 

  $("#resultsp").show(); 
  
var payname = $("#addpay").val();


  $.post("processpaytypes.php", {paytype : payname }, function(data){
   if (data.length>0){ 

   $("#resultsp").html(data); 
   } 
  }) 
}

</script>
<?


?>
