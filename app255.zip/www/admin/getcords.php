<?
include "slide.php";
?>
<h4>Enter Address seperated by commas eg:- 2 Some Street, Suburb, Town, Country<form name='geoform'>
<label>Enter Address</label>
<input type='text' name='address' /><br>
<input type='button' name='submit' value='Go' onclick='showlat();' /></form>
<div id='resultsx'>f</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js" type="text/javascript"></script>
<script>

var nam;
function showlat() { 
$.ajaxSetup({ cache: false });
$("#resultsx").show();
nam = document.geoform.address.value;
var addre = nam.split(",").join('');
var addres = addre.split(" ").join('_');

var url = "geocodeaddress.php?nam="+addres;
$('#resultsx').load(url);
} 
</script>