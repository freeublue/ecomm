<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../../lib.php";
include "../../confadmin.php";
?><h4>Edit Links are found on each page.</h4>
<p>View changes after completion</p>
<p>
<?
$sq = $db->query("SELECT * FROM about");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 
echo "<a href='editabout.php?id=$row[ab_id]'>$row[ab_title]</a><br>";
} 
?></p>
<iframe width='600px' src='../about.php'><iframe>
</div></div>
</div></body></html>