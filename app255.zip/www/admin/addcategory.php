<?
require "bootstraptop.php";
require "slide.php";
?>
<style>
#results{ 
display:none;

} </style>
<script>
function validateForm()
{
var x=document.forms["myform"]["addtype"].value;
if (x==null || x=="")
  {
  alert("Title must be filled out");
  return false;
  } 



   



}
</script>
<div class='container'>
<div class='row'>
<div class='col-6'>
<?
include "../../lib.php";
include "../../confadmin.php";

echo "<form name='myform'>";
echo "<h4>Enter Type</h4><p>Types serve as categories. Each group may be inserted into a matching categories. </p><br />";

           echo "<input id='addtype' name='addtype' type='text'> 
               
                  <button id='add_em' class='btn btn-primary' type='button'> 
                     Go! 
                  </button></form<p><div id='results'>gg</div></p>"; 


?>
</div>
<div class='col-6'>

<?php
echo "<h4>Edit Type</h4><p>Types serve as categories. Each group may be inserted into a matching categories. </p><br />";
$sql = $db->query("SELECT * FROM groupcate LIMIT 0, 30 ");
while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 

echo "<span><a href='editcate.php?ty=$row[gc_id]'><i class='far fa-edit'></i> $row[gc_title] </a></span>|<span><a href='deletetype.php?ty=$row[gc_id]'><i class='fa fa-trash' aria-hidden='true'></i> $row[gc_title]</a></span><br />"; } 
?>

</div>
</div>










<div style='margin-top:3em;' class='row'>
<div class='col-6'>
<?



echo "<h4>Enter Payment Option</h4><p>Payment Options such as Cash, EFT, External payment gateway(we offer Payfast and Paypal). </p><br />";

           echo "<form action='processpaytypes.php' method='post' name='payform'><div class='checkbox'> 
   <label><input name='payt[]' type='checkbox' value='PayFast'>PayFast</label> 
</div> 
<div class='checkbox'> 
   <label><input name='payt[]' type='checkbox' value='PayPal'>PayPal</label> 
</div> 
<div class='checkbox'> 
   <label><input type='checkbox' name='payt[]' value='Cash'>Cash</label> 
</div>
 <div class='checkbox'> 
   <label><input type='checkbox' name='payt[]' value='EFT'>EFT</label> 
</div>  
<div class='checkbox'> 
   <label><input type='checkbox' name='payt[]' value='COD'>COD</label> 
</div>
<div class='checkbox'> 
   <label><input type='checkbox' name='payt[]' value='Cash_on_Collection'>Cash on Collection</label> 
</div>

              <input class='btn btn-primary' value='Add' type='submit'> 
                     
                  </form>
 
<p></p>"; 


?>
</div>
<div class='col-6'>

<?php
echo "<h4>Edit Payment Options</h4><p>Payment. </p><br />";
$sql = $db->query("SELECT * FROM paytypes LIMIT 0, 30 ");
while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 

echo "<a href='editbrand.php?id=$row[pt_id]'>edit $row[pt_title] $row[ty_id]</a>|<a href='deletebrand.php?id=$row[pt_id]'>delete $row[pt_title]</a><br />"; } 
?>

</div>
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js" type="text/javascript"></script>
<script>
$(document).ready(function(){ 

$("#results").slideUp(); 

    $("#add_em").click(function(e){ 
        e.preventDefault(); 

        ajax_sear(); 
    }); 
     




}); 


function ajax_sear(){ 

  $("#results").show(); 
  
var typename = $("#addtype").val();


  $.post("processtype.php", {type : typename }, function(data){
   if (data.length>0){ 

   $("#results").html(data); 
   } 
  }) 
} 




</script>

