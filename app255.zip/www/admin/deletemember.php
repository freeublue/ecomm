<?
require "../../confadmin.php";
$ptype = $_REQUEST[id];
echo "$ptype added to data<br>";
$db->exec("DELETE FROM groupmem WHERE gm_id = '$ptype'");