<?
require "bootstraptop.php";
require "slide.php";
include "../../bootlib.php";
include "../../confadmin.php";

?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<h4>Order Details</h4>
</div>
</div>
<div class='row'>
<div class='col-12'>
gm_gid, gm_role, gm_userid, gm_status
<?


$id = $_REQUEST["id"];

echo "<table class='table-bordered' width='100%'><tr>
      <td><b>Grouo ID</b></td>
      <td><b>Role</b></td>
      <td><b>Client ID</b></td>
      <td><b>Status</b></td>

   

      </tr>";
$sq = $db->query("SELECT * FROM groupmem");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 
echo "<tr><td> $row[gm_gid]</td>";
echo "<td> $row[gm_role]</td>";
echo "<td> $row[gm_userid]<a href='viewmember.php?id=$row[gm_userid]'>View</a></td>";
echo "<td> $row[gm_status]</td></tr>";


} 
?></table><br><a href='index.php'>Home</a></br></div></div></div>