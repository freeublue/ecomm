<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../../lib.php";
include "../../confadmin.php";
echo "<h4>Add Members to Groups</h4><br>";
$sql = $db->query("SELECT * FROM groupcl");
while($rows = $sql->fetchArray(SQLITE3_ASSOC ) ) { 
$catemain = $rows[gr_cateid];

echo "<a href='addmember.php?id=$rows[gr_id]&&cate=$catemain'>$rows[gr_title] $rows[gr_id]</a>";  } 
?>
</div></div>
<div class='row'>
<div class='col-12'>
<?
echo "<h4>Edit Members in Group</h4><br>";
$sql = $db->query("SELECT * FROM groupcl");
while($rows = $sql->fetchArray(SQLITE3_ASSOC ) ) { 
$catemain = $rows[gr_cateid];

echo "<a href='editmemberlead.php?id=$rows[gr_id]'>$rows[gr_title] $rows[gr_id]</a>";  } 
?>
</div></div>
</div></body></html>
