<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?

$connection = "../../confadmin.php";
$tb = "workshop2";
require "../functions/libsql.php";
//groupid addtype img descp equip price fr tfr tto discount discountcr
$groupid = $_POST[groupid];
$title = $_POST[addtype];
$img = $_POST[img];
$descp = $_POST[descp];
$equip = $_POST[equip];
$price = $_POST[price];
$fr = $_POST[fr];
$tfr = $_POST[tfr];
$tto = $_POST[tto];
$discount = $_POST[discount];
$discountcr = $_POST[discountcr];
$subcate = $_POST[subcate];
$status = 1;
echo "groupid $groupid title $title img $img descp $descp equip $equip price $price fr $fr tfr $tfr $tto tto disount $discount criteria $discountcr subcare $subcate status $status<br>";
$fieldsarray = array("ws_groupid", "ws_subcateid", "ws_title", "ws_descp", "ws_image", "ws_price", "ws_equipment", "ws_datefr", "ws_timefr", "ws_timeto", "ws_status", "ws_discount", "ws_discount_criteria");

$fieldsarray2 = array($groupid, $subcate, $title, $descp, $img , $price, $equip, $fr, $tfr, $tto, $status, $discount, $discountcr);
instb($connection, $tb, $fieldsarray, $fieldsarray2);
?>
</div></div>
</div></body></html>
