
 <?
 require "../../confadmin.php";
 echo "<div class='row'>";
 echo "<div class='col-12'>";
echo "<table class='table-striped'><tr><td><b>Date</b></td><td><b>Sales</b></td></tr>";
 $sqr = $db->query("SELECT wo_orderdate, wo_producttype, sum(wo_price) as woprice FROM wsorders WHERE wo_producttype = 'workshop' GROUP BY wo_orderdate");
while($rowr = $sqr->fetchArray(SQLITE3_ASSOC)) {  
echo "<tr><td>$rowr[wo_orderdate] $rowr[woprice]</td></tr>"; } 
echo "</table>";
echo "</div></div>";

 echo "<div class='row'>";
 echo "<div class='col-12'>";
echo "<table class='table-striped'><tr><td><b>Date</b></td><td><b>Sales</b></td></tr>";

$sq = $db->query("SELECT  strftime('%m', wo_orderdate) as wodate, SUM(wo_price) as wopr
FROM    wsorders
GROUP BY strftime('%m', wo_orderdate)");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) {  
$q[$row[wodate]] = $row[wopr];
echo "<tr><td>$row[wodate]</td><td> $row[wopr]</td></tr>"; } 
echo "</table>";


foreach($q as $w) { 
echo "$w<br>";
} 


$tota = array_sum($q);
echo "$tota<br>";
$m11 = ($q[11]/$tota) * 100;
$m12 = ($q[12]/$tota) * 100;
$m11 = ceil($m11);
$m12 = ceil($m12);
echo "m11 $m11 m12 $m12<br>";