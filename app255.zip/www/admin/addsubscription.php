<?
require "bootstraptop.php";
require "slide.php";
?>
<style>
#results{ 
display:none;

} </style>
<div class='container'>
<div class='row'>
<div class='col-6'>
<?
include "../../lib.php";
include "../../confadmin.php";

echo "<form>";
echo "<h4>Enter Subscription</h4><p>Enter features as a comma seperated list in description. </p><br />";
  echo "<p><input id='addtitle' name='addtitle' placeholder='Title' type='text'></p><br>";
    echo "<p><input id='adddescp' name='adddescp' placeholder='Comma seperated list of features' type='text'></p><br>";
      echo "<p><input id='addimage' name='addimage' placeholder='Image .jpg or .png icon 200px by 200px' type='text'></p><br>";
        echo "<p><input id='addprice' placeholder='Price' name='addprice' type='text'></p><br>";
  echo "<p><select name='addstatus' id='addstatus'>
  <option value='active'>Active</option>
  <option value='inactive'>In Active</option>
  </select>
  </p><br>";
           echo "<input id='addrepeat' name='addrepeat' placeholder='Regularity' type='text'><br><p> 
               
                  <button id='add_em' class='btn btn-primary' type='button'> 
                     Go! 
                  </button></form></p><p><div id='resultsp'>gg</div></p>"; 


?>
</div>
<div class='col-6'>

<?php
echo "<h4>Edit Subscription</h4><p>Features are a comma seoerated list in description field. </p><br />";
$sql = $db->query("SELECT * FROM subscription LIMIT 0, 30 ");
while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 

echo "<a href='editsubs.php?ty=$row[sb_id]'>edit $row[sb_title] $row[sb_id]</a>|<a href='deletesubs.php?ty=$row[sb_id]'>delete $row[sb_title]</a><br />"; } 
?>

</div>
</div>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js" type="text/javascript"></script>
<script>
$(document).ready(function(){ 


$("#resultsp").slideUp();
$("#add_em").click(function(e) { 
        e.preventDefault(); 

        ajax_sepay(); 
});

}); 


function ajax_sepay(){ 

  $("#resultsp").show(); 
  
var sb_title = $("#addtitle").val();
var sb_descp = $("#adddescp").val();
var sb_image = $("#addimage").val();
var sb_title = $("#addtitle").val();
var sb_price = $("#addprice").val();
var sb_status = $("#addstatus").val();
var sb_repeat = $("#addrepeat").val();

  $.post("processsubscription.php", {sbtitle : sb_title, sbdescp : sb_descp, sbimage : sb_image, sbprice : sb_price, sbrepeat : sb_repeat, sbstatus : sb_status}, function(data){
   if (data.length>0){ 

   $("#resultsp").html(data); 
   } 
  }) 
}

</script>