<?
require "bootstraptop.php";
require "slide.php";
include "../../bootlib.php";
include "../../confadmin.php";

?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<h4>Order Details</h4>
</div>
</div>
<div class='row'>
<div class='col-12'>

<?


$id = $_REQUEST["id"];

echo "<table class='table-bordered' width='100%'><tr>
      <td><b>Group ID</b></td>
      <td><b>Role</b></td>
      <td><b>Client ID</b></td>
      <td><b>Status</b></td>
      <td><b>Edit</b></td>
      <td><b>Delete</b></td>

   

      </tr>";
$sq = $db->query("SELECT * FROM groupmem WHERE gm_gid = '$id'");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 
echo "<tr><td> $row[gm_gid]</td>";
echo "<td> $row[gm_role]</td>";
echo "<td> $row[gm_userid]<a href='viewmember.php?id=$row[gm_userid]'>View</a></td>";

echo "<td> $row[gm_status]</td>";
echo "<td><a href='editmember.php?id=$row[gm_id]'><i class='far fa-edit'></i></a></td>";
echo "<td><a href='deletemember.php?id=$row[gm_id]'><i class='far fa-trash'></i></td>";



echo "</tr>";


} 
?></table><br><a href='index.php'>Home</a></br></div></div></div>