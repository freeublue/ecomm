<style>

.row{margin-top:2em; }
</style>
<?
require "bootstraptop.php";
require "slide.php";
include "../../bootlib.php";
include "../../confadmin.php";
?>

<?php

$year = date("Y");
$startyear = "2018-01-01";
$endyear = "2018-12-31";
$sql = $db->query("SELECT * FROM locate");
while($rowx = $sql->fetchArray(SQLITE3_ASSOC ) ) { 

$locateid = "$rowx[lc_id]";
$locatetitle[] = $rowx[lc_title]; 


} 
?>
<div class='container-fluid'>
<div class='row'>
<div class='col-12'>
<h1>Sales</h1>
</div></div>
<?

 echo "<div class='row'>";
 echo "<div class='col-6'><h4 class='text-center'>Sales by Day</h4>";
echo "<table width='100%' class='table-striped'><tr><td><b>Date</b></td><td><b>Sales</b></td></tr>";
 $sqr = $db->query("SELECT wo_orderdate, wo_producttype, sum(wo_price) as woprice FROM wsorders WHERE wo_producttype = 'workshop' AND wo_orderdate BETWEEN '$startyear' AND '$endyear' GROUP BY wo_orderdate");
while($rowr = $sqr->fetchArray(SQLITE3_ASSOC)) {  
echo "<tr><td>$rowr[wo_orderdate]</td><td>R $rowr[woprice]</td></tr>"; } 
echo "</table>";

echo "</div>";
 echo "<div class='col-6'><h4 class='text-center'>Sales by Month</h4>";

echo "<table width='100%' class='table-striped'><tr><td><b>Date</b></td><td><b>Sales</b></td></tr>";

$sq = $db->query("SELECT  strftime('%m', wo_orderdate) as wodate, SUM(wo_price) as wopr
FROM    wsorders WHERE wo_orderdate BETWEEN '$startyear' AND '$endyear'
GROUP BY strftime('%m', wo_orderdate)");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) {  
$q[$row[wodate]] = $row[wopr];
echo "<tr><td>$row[wodate]</td><td>R $row[wopr]</td></tr>"; } 
echo "</table>";
echo "</div></div>";
?>


<div class='row'>
<div class='col-12'>
<canvas id="myChart"></canvas>
</div></div>
<div class='col-12'>
<canvas id="myChartr"></canvas>
</div></div>

<div class='row text-center'>
<div class='col-12 text-center'>
<h4>Manage Orders</h4>
<?

$sq = $db->query("SELECT * FROM wsorders WHERE wo_producttype = 'workshop' ORDER BY wo_id DESC LIMIT 6");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 


echo "<a href='vieword.php?id=$row[wo_id]'>View Order Number $row[wo_ordernum] Order Status $row[wo_orderstatus]</a>|<a href='refundord.php?id=$row[wo_id]'>Refund Order Number $row[wo_ordernum] Order Status $row[wo_orderstatus]</a></br><br>";


} 
echo "<a class='btn btn-dark' href='ordersview.php'>View More</a>";
?>


</div></div>
<div style='margin-top:2em;' class='row'>
<div class='col-6'>
<h4>Subscriptions Per Area</h4>
<div id="canvas-holder">
<canvas id="chart-area"></canvas>
	</div></div><div class='col-6'>
<h4>Manage Subscriptions</h4>
<?

$sq = $db->query("SELECT * FROM wsorders WHERE wo_producttype = 'subscription' AND wo_orderdate BETWEEN '$startyear' AND '$endyear'");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 


echo "<a href='viewsub.php?id=$row[wo_id]'>Order Number $row[wo_ordernum] Order Status $row[wo_orderstatus]</a></br>";



} 
?></div></div>

   <div class='row'>
     <div class='col-12'>
      
         
        
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Mobile</th>
                  <th>Email</th>
                  
                  <th>Start Date</th>
                  
                </tr>
              </thead>
              <tfoot>
                <tr>
                  <th>Name</th>
                  <th>Mobile</th>
                  <th>Email</th>
                  
                  <th>Start Date</th>
                  
                </tr>
              </tfoot>
              <tbody>
              <?php
              require "../../lib.php";
              
       $stmt = $db->query("SELECT * FROM cust1");
while ($row = $stmt->fetchArray(SQLITE3_ASSOC)) {
    
$now = date("Y-m-d");
$phone = cr($stp, $row[cu_phone_mobile], $action = 'ivg');
$email = cr($stp, $row[cu_email], $action = 'ivg');



            echo "<tr>";
            
               echo "<td>" . $row["cu_fname"]. ' ' . $row["cu_lname"] . "</td>";
               
               echo "<td>" . $phone . "</td>"; 
               echo "<td>" . $email . "<br><a href='message.php?id=$row[cu_id]'>Message</a><br><a href='mail.php?id=$row[cu_id]'>Email</a></td><td>" . $row["cu_dayfirst"] . "</td>"; 
               echo "</tr>";
               

               } 
               ?>
              
             
              </tbody>
            </table>
            </div>
            </div>





</div>
<?
$sq = $db->query("SELECT  strftime('%m', wo_orderdate) as wodate, SUM(wo_price) as wopr
FROM    wsorders WHERE wo_orderdate BETWEEN '$startyear' AND '$endyear'
GROUP BY strftime('%m', wo_orderdate)");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) {  
$q[$row[wodate]] = $row[wopr];
 } 
foreach($q as $w) { 



} 
$tota = array_sum($q);

for($i=1;$i<13;$i++) { 
$m[$i] = ($q[$i]/$tota) * 100; } 

foreach($m as $r) { 
$p[] = ceil($r);

} 



?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>

<script>
var m1 = "<? echo $p[0]; ?>";
var m2 = "<? echo $p[1]; ?>";
var m3 = "<? echo $p[2]; ?>";
var m4 = "<? echo $p[3]; ?>";
var m5 = "<? echo $p[4]; ?>";
var m6 = "<? echo $p[5]; ?>";
var m7 = "<? echo $p[6]; ?>";
var m8 = "<? echo $p[7]; ?>";
var m9 = "<? echo $p[8]; ?>";
var m10 = "<? echo $p[9]; ?>";
var m11 = "<? echo $p[10]; ?>";
var m12 = "<? echo $p[11]; ?>";
var ctx = document.getElementById('myChart').getContext('2d');
var chart = new Chart(ctx, {
    // The type of chart we want to create
    type: 'line',

    // The data for our dataset
    data: {
        labels: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
        datasets: [{
            label: "SALES PER MONTH FOR WORKSHOPS",
            backgroundColor: 'rgb(255, 99, 132)',
            borderColor: 'rgb(255, 99, 132)',
            data: [m1, m2, m3, m4, m5, m6, m7, m8, m9, m10, m11, m12],
        }]
    },

    // Configuration options go here
    options: {}
});
</script>
<script>
var fst = "<? echo $locatetitle[0]; ?>";
var fst1 = "<? echo $locatetitle[1]; ?>";
var fst2 = "<? echo $locatetitle[2]; ?>";
var fst3 = "<? echo $locatetitle[3]; ?>";
var fst4 = "<? echo $locatetitle[4]; ?>";
var fst5 = "<? echo $locatetitle[5]; ?>";
var fst6 = "<? echo $locatetitle[6]; ?>";
var fst7 = "<? echo $locatetitle[7]; ?>";
var fst8 = "<? echo $locatetitle[8]; ?>";
	var ctx = document.getElementById("chart-area").getContext('2d');
var myChart = new Chart(ctx, {
  type: 'pie',
  data: {
    labels: [fst, fst1, fst2, fst3, fst4, fst5, fst6, fst7, fst8],
    datasets: [{ 
    
      backgroundColor: [
        "#2ecc71",
        "#3498db",
        "#95a5a6",
        "#9b59b6",
        "#f1c40f",
        "#e74c3c",
        "#34495e",
        "00ff00",
        "#00ffff"
      ],
      data: [12, 19, 3, 17, 28, 24, 7, 12, 18]
    }]
  }
});

</script>
<script>
var ctx = document.getElementById('myChartr').getContext('2d');
var myChart = new Chart(ctx, {
  type: 'line',
  data: {
    labels: ['M', 'T', 'W', 'T', 'F', 'S', 'S'],
    datasets: [{
      label: 'Completed Sales',
      data: [12, 19, 3, 17, 6, 3, 7],
      backgroundColor: "rgba(153,255,51,0.4)"
    }, {
      label: 'Abandoned Sales',
      data: [2, 29, 5, 5, 2, 3, 10],
      backgroundColor: "rgba(255,153,0,0.4)"
    }]
  }
});
</script>
<script>

    $('#dataTable').DataTable();

</script>


   
<?
require "../bootstrapbottom.php";
?>