
<?php
include "../../confadmin.php";

$ptype = $_POST[type];
$id = $_POST[id];
$db->exec("UPDATE typesca SET ty_title = '$ptype' WHERE ty_id = '$id'");


?>