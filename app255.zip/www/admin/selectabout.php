<table width='800px' border=1><tr><td width='500px' valign='top'>
<?php
include "../../confadmin.php";
require "../../lib.php";
$sql = $db->query("SELECT * FROM about");


while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 


echo "$row[ab_title]<br />";
echo "$row[ab_suhead]<br />";
echo "$row[ab_image]<br />";
echo "$row[ab_txt]<br />"; } 
?>
</td><td width='100px' valign='top'><a href='index.php'>Home</a></td></tr></table>
