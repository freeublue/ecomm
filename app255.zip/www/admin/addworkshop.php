<?
require "bootstraptop.php";
require "slide.php";
include "../functions/bootlib.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../../lib.php";
include "../../confadmin.php";
echo "<form name='ws' action='processws.php' method='post'>";
$id = $_REQUEST[id];
$cate = $_REQUEST[cate];
echo "$id<br>";
echo "<label>Add to Group</label><br>";
echo "<select name='subcate'>";
$sql = $db->query("SELECT * FROM subcate WHERE subcate_gcid = '$cate'");
while($rows = $sql->fetchArray(SQLITE3_ASSOC ) ) { 
echo "<option value='$rows[subcate_id]'>$rows[subcate_title] $rows[subcate_gcid]</option>";  } 
echo "</select><br>";
echo "<label>Workshop Name</label><br><input id='addtype' name='addtype' /><label>Workshop Image</label><br>
           <input id='img' name='img' type='text'><br>
           <label>Workshop Motto</label><br>
           <textarea rows='10' cols='10' name='motto'></textarea><br>";
           echo "<label>Workshop Description</label><br>
           <textarea rows='10' cols='30' name='descp'></textarea><br>";
                   echo "<label>Workshop Equipment</label><br>
           <textarea rows='10' cols='30' name='equip'></textarea><br>";
           
 $input_labelc1 = 'Price';
 $input_typec1 = 'number';
 $sizec1 = 'col-xs-8 col-md-12';
 $input_idc1 = 'price';
 $va1 = $price;
 input_formv($input_idc1, $input_typec1, $input_labelc1, $sizec1, $va1);
            
 $input_labelc12 = 'Date';
 $input_typec12 = 'date';
 $sizec12 = 'col-xs-8 col-md-12';
 $input_idc12 = 'fr';
 $va12 = $fromdate;
 input_formv($input_idc12, $input_typec12, $input_labelc12, $sizec12, $va12);
             
 $input_labelc12 = 'Time From';
 $input_typec12 = 'time';
 $sizec12 = 'col-xs-8 col-md-12';
 $input_idc12 = 'tfr';
 $va12 = $fromdate;
 input_formv($input_idc12, $input_typec12, $input_labelc12, $sizec12, $va12);

  $input_labelc12 = 'Time To';
 $input_typec12 = 'time';
 $sizec12 = 'col-xs-8 col-md-12';
 $input_idc12 = 'tto';
 $va12 = $fromdate;
 input_formv($input_idc12, $input_typec12, $input_labelc12, $sizec12, $va12);
    
$input_labelc12 = 'Discount as a Percentage';
 $input_typec12 = 'number';
 $sizec12 = 'col-xs-8 col-md-12';
 $input_idc12 = 'discount';
 $va12 = $discount;
 input_formv($input_idc12, $input_typec12, $input_labelc12, $sizec12, $va12);
 $input_labelc12 = 'Discount Criteria';
 $input_typec12 = 'text';
 $sizec12 = 'col-xs-8 col-md-12';
 $input_idc12 = 'discountcr';
 $va12 = 'Subscription';
 input_formv($input_idc12, $input_typec12, $input_labelc12, $sizec12, $va12);
 echo "<input type='text' name='groupid' value='$id' />";
           ?>
           
                  <button id='add_em' class='btn btn-primary' type='submit'> 
                     Go! 
                  </button></form>


?>
</div></div>
</div></body></html>
groupid subcate addtype img descp equip price fr tfr tto discount discountcr
ws_groupid, ws_subcateid, ws_title, ws_descp, ws_image, ws_vid, ws_principle, ws_subprinciples, ws_price, ws_equipment, ws_datefr, ws_dateto, ws_timefr, ws_timeto, ws_addressname, ws_address1, ws_address2, ws_mobile, ws_phone, ws_town, ws_suburb, ws_province, ws_zip, ws_lat, ws_lng, ws_type, ws_status, ws_discount, ws_discount_criteria, ws_repeat