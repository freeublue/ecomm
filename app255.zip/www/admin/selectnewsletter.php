<table width='800px' border=1><tr><td width='500px' valign='top'>
<?php
error_reporting(0);
include "slide.php";
include "../../confadmin.php";
require "../../lib.php";
$sql = $db->query("SELECT * FROM nleta");


while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 
$em = cr($stp, $row[nl_em], $action = 'ivg');

echo "$row[nl_name]<br />";
echo "$em<br />";
echo "$row[ni_va]<br />"; } 
?>
</td><td width='100px' valign='top'><a href='index.php'>Home</a></td></tr></table>
