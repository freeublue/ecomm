<?
require "bootstraptop.php";
require "../functions/libsql.php";
require "slide.php";

?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
$tb = "businessname";
$connection = "../../confadmin.php";
if (EMPTY($_POST[title] ) ) { 
echo "You must add a name"; } 
elseif (EMPTY($_POST[product] ) ) { 
echo "Please enter a short phrase"; } 
elseif(EMPTY($POST[product]) ) { 
echo "A product must be added"; } else { 
$webname = cl($_POST[title]);
$phrase = cl($_POST[phrase]);
$industry = cl($_POST[industry]);
$bgimg = $_POST[bgimg];
$logo = $_POST[logo];
$product = cl($_POST[product]);


echo "webname $webname phrase $phrase  bgimg $bgimg logo $logo product $product industry $industry";
$fieldsarray2 = array($webname, $phrase, $logo, $bgimg, $industry, $product);
$fieldsarray = array("webname", "catchphrase", "logo" , "backgroundimg" , "industry", "producttype");
instb($connection, $tb, $fieldsarray, $fieldsarray2);
echo "<a href='index.php'>Return Home data added</a>"; } 

?>


</div></div>
</div></body></html>