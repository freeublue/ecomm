<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../functions/libsql.php";
$tb = "mentor";
$connection = "../../confadmin.php";

$title = $_POST[addtype];
echo "$title";
if (EMPTY($_POST[addtype]) ) { 
echo "Please enter a title"; } else { 
$ar = array('png' , 'jpg' , 'gif', 'jpeg');
$fill = strtolower($_FILES['userfile'] ['name']); 
$fil = substr($fil1, -3); 
echo "file $fill sub $fil";
if ($fil != $ar['0'] || $fil != $ar['1'] || $fil != $ar['2'] || $fil != $ar['3']) 
{ 
echo "You have uploaded a file in the wrong formatt, only jpg, gif or png allowed"; 
} 




echo $_FILES['userfile'] ['tmp_name'];
$fileName = $_FILES['userfile'] ['name'];
$tmpName = $_FILES['userfile'] ['tmp_name'];
$fileSize = $_FILES['userfile'] ['size'];
$fp = fopen($tmpName, 'r');
$content = fread($fp, $fileSize);
$content = addslashes($content);
fclose($fp);
$picture = str_replace(' ', '_', $tmpName);
$source = $picture;
$na = time();

$target = '../pic/' . $fileName;
$newname = '../pic/' . $na . '.jpg';
$newna = 'pic/' . $na . '.jpg';

move_uploaded_file($source, $newname );

$newname = 'pic/' . $na . '.jpg';
$wq = rename($target, $newname);
$image = $newname;
echo "File<b> $newname</b> uploaded as id= $id<br>";



echo "File<b> $newname</b> uploaded<br>";
echo "<b>All images in pic directory gallery</b></br >"; 
echo "<b><a href='index.php'>Return Home</a></b></br >"; 

$title = cl($_POST[addtype]);

$descp = cl($_POST[descp]);
$skills = cl($_POST[skills]);
$edu = cl($_POST[edu]);


$fieldsarray = array("mn_title", "mn_descp", "mn_image", "mn_skills", "mn_education");
$fieldsarray2 = array($title, $descp, $image, $skills, $edu);

instb($connection, $tb, $fieldsarray, $fieldsarray2);

 } 
?>
</div></div>
</div></body></html>

