<?
$connection = "../../confadmin.php";
require "../functions/libsql.php";
$tb = "subscription";
$sb_title = $_POST[sbtitle];
$sb_descp = $_POST[sbdescp];
$sb_image = $_POST[sbimage];
$sb_price = $_POST[sbprice];
$sb_status = $_POST[sbstatus];
$sb_repeat = $_POST[sbrepeat];
echo "$sb_title  $sb_descp $sb_image $sb_price $sb_status $sb_repeat added to data<br>";
$fieldsarray = array("sb_title", "sb_descp", "sb_image", "sb_price", "sb_status" , "sb_repeat");
$fieldsarray2 = array($sb_title, $sb_descp, $sb_image, $sb_price, $sb_status , $sb_repeat);
instb($connection, $tb, $fieldsarray, $fieldsarray2);
?>

