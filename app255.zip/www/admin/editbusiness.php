<?
require "../bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-6'>

<?
include "../../lib.php";
include "../../confadmin.php";
include "../functions/bootlib.php";
$id = $_POST[id];
$sql = $db->query("SELECT * FROM businessname");
while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 
 echo "<div class='container-fluid'><form action='processeditbusiness.php' method='post'>";
 $input_labela = 'Name of Business/Website';
 $input_typea = 'text';
 $sizea = 'col-12';
 $input_ida = 'title';
 $val = $row[webname];
 input_formv($input_ida, $input_typea, $input_labela, $sizea, $val);
 $input_label = 'Image Logo File:200px wide';
 $input_type = 'text';
 $size = 'col-12';
 $input_id = 'logo';
 $va = $row[logo];
 input_formv($input_id, $input_type, $input_label, $size, $va);
 $input_labelb = '3 word catch phrase';
 $input_typeb = 'text';
 $sizeb = 'col-12';
 $input_idb = 'phrase';
 $valb = $row[catchphrase];
 input_formv($input_idb, $input_typeb, $input_labelb, $sizeb, $valb);
 $input_labelc = 'Product Type';
 $input_typec = 'text';
 $sizec = 'col-12';
 $input_idc = 'product';
 $valc = $row[producttype];
 input_formv($input_idc, $input_typec, $input_labelc, $sizec, $valc);
  $input_labeln = 'Industry';
 $input_typen = 'text';
 $sizen = 'col-12';
 $input_idn = 'industry';
 $valn = $row[industry];
 input_formv($input_idn, $input_typen, $input_labeln, $sizen, $valn);

 echo "<input type='text' name='id' value='$row[bus_id]' />";
 
   $input_labelc9 = 'Background Image';
 $input_typec9 = 'text';
 $sizec9 = 'col-xs-8 col-md-8';
 $input_idc9 = 'bgimg';
 $val9 = $row[backgroundimg];
 input_formv($input_idc9, $input_typec9, $input_labelc9, $sizec9, $val9);
 
echo "<button class='btn btn-lg btn-primary btn-block' type='submit' name='submit'>Submit</button><br />";
 echo "</form></div>"; } 
 ?>
          
</p>

</div>
<div class='col-6'>

</div>


</div>
</div></body></html>