<?
require "../confad.php";
require "../lib.php";
$_SESSION[customer] = '0526060893';
$customer = cr($stp, ($_SESSION[customer]), $action = 'enc');
if(isset($_SESSION[customer] ) ) { 
$sqlc = $db->query("SELECT * FROM cust1 WHERE cu_phone_mobile = '$customer'");
while($row = $sqlc->fetchArray(SQLITE3_ASSOC) ) { 
$newcustid = $row[cu_id]; 
} 
echo "<div id='cartDetails'><table width='100%'><tr><td>Workshop</td><td>Price</td><td>Date</td><td>Time</td><td>Discount</td><td>Remove</td></tr>";
$sq = $db->query("SELECT
tempord.tm_id,
        tempord.tm_wsid,
        tempord.tm_clientid,
        workshop2.ws_id,
        workshop2.ws_title,
        workshop2.ws_price,
        workshop2.ws_datefr,
        workshop2.ws_timefr,
        workshop2.ws_timeto,
        workshop2.ws_discount,
        workshop2.ws_descp
FROM tempord  

INNER JOIN workshop2 ON
        tempord.tm_wsid = workshop2.ws_id WHERE tempord.tm_clientid = '$newcustid'");
        while($rowg = $sq->fetchArray(SQLITE3_ASSOC ) ) { 
        $newprice = $rowg[ws_price] - ($rowg[ws_price] * ($rowg[ws_discount]/100));
        
        $totadds[] = $newprice;
        
        echo "<tr><td>$rowg[ws_title]</td>";
echo "<td>R $rowg[ws_price]</td>";
echo "<td>$rowg[ws_datefr]</td>";
echo "<td><b>From:</b> $rowg[ws_timefr]<br>";
echo "<b>To:</b> $rowg[ws_timeto]</td>";
echo "<td>$rowg[ws_discount] %</td><td id='$rowg[tm_id]' onclick='deleteFromCart(this.id);'>x</td></tr>";
        } } 
        $total = array_sum($totadds);
        echo "<tr><td colspan='5'></td><td>R $total</td></tr></table></div>";
echo "<a class='btn btn-dark' href='checkout.php'>Check Out</a><br>";
echo "<div id='resultsh'></div>";
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js" type="text/javascript"></script>
<script>

var nam;
function deleteFromCart(nam) { 
$.ajaxSetup({ cache: false });
$("#resultsh").show();

document.getElementById("cartDetails").style.display = "none";
var url = "deletecart.php?nam="+nam;
$('#resultsh').load(url);
} 
</script>
        
        ws_groupid, ws_subcateid, ws_title, ws_descp, ws_image, ws_vid, ws_principle, ws_subprinciples, ws_price, ws_equipment, ws_datefr, ws_dateto, ws_timefr, ws_timeto, ws_addressname, ws_address1, ws_address2, ws_mobile, ws_phone, ws_town, ws_suburb, ws_province, ws_zip, ws_lat, ws_lng, ws_type, ws_status, ws_discount, ws_discount_criteria