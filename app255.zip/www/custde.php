<?
session_start();

require "bootstraptop.php";
require "functions/bootlib.php";

require "header.php";

if(isset($_SESSION[customer]) ) {  
?>
<div class='container-fluid'>
<div style='margin-top:5em;' class='row'>
<div class='col-6'><h4 style='color:gray;'>Enter Details for workshops and subscriptions</h4><p><? echo $day; ?></p><form action='processcust.php' method='post'>
<?
require "../confad.php";
require "../lib.php";
$customer = cr($stp, ($_SESSION[customer]), $action = 'enc');
$sqlc = $db->query("SELECT * FROM cust1 WHERE cu_phone_mobile = '$customer'");
while($row = $sqlc->fetchArray(SQLITE3_ASSOC) ) { 
$newcustid = $row[cu_id];
echo "customer $newcustid<br />"; 

 
$input_id = 'name_first';
$input_type = 'text';
$input_label = 'First Name';
$size = 'col-6';
 input_formv($input_id, $input_type, $input_label, $size, $row[cu_fname]);
 $input_ids = 'name_last';
$input_type = 'text';
$input_labels = 'Last Name';
$size = 'col-6';
 input_formv($input_ids, $input_type, $input_labels, $size, $row[cu_lname]);
 $input_idx = 'em';
$input_typex = 'email';
$input_labelx = 'Email';
$size = 'col-6';
$email = cr($stp, $row[cu_email], $action = 'ivg');
 input_formv($input_idx, $input_typex, $input_labelx, $size, $email);
  $input_idxw = 'contacttitle';
$input_typexw = 'text';
$input_labelxw = 'Contact Title, MS MR MISS MRS';
$size = 'col-6';
 input_formv($input_idxw, $input_typexw, $input_labelxw, $sizew, $row[cu_contact_title]); } 
 
 
 
?>


<input type='submit' class='btn btn-danger' value='submit' name='submit' /></form>





<div  style='background: black;color:white;' class='row text-center'>
<? } 

else { echo "You must be logged in to proceed"; } 
?>

<div  class='col-12'>
<h2>Footer</h2>
<h4>Sub Footer</h4></div>
</div>


<?
echo "<div  style='background: black;color:white;padding:12px;' class='row'>";
echo "<div  class='col-4'>";
$sizesx = 9;
$stylex = 'liststy';
$listx = 'ul';
$clax = 'list-unstyled';
$contx = array("Eastern Cape", "Free State", "Gauteng", "KwaZulu-Natal", "Limpop", "Mpumalanga", "Northern Cape", "North West");
$optstylex = array('tt1', 'tt2', 'tt3', 'tt4', 'tt5', 'tt6');
$lisx = blist($stylex, $listx, $clax, $sizex, $contx, $optstylex);
echo $lisx; 
?>





</div>
<div  class='col-4'>xx</div>
<div  class='col-4'>qq</div>
</div>

<div  style='background: black;color:white;' class='row text-center'>

<div  class='col-12'>
<p class='m-0 text-center text-white'>Copyright &copy; Public Service Internship Club 2018</p><p style='text-align:center;'><i class='fab fa-twitter fa-1x' style='color:#d9534f;'></i><i class=fab fa-instagram fa-1x' style='color:#d9534f;'></i><i class='fab fa-facebook-f fa-1x' style='color:#d9534f;'></i></p><p><img height='30px' src='vm.png' /></p>
</div>

</div>


</div><!container>

<?
require "bootstrapbottom.php";
?>