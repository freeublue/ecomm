<?
require "bootstraptop.php";
require "functions/bootlib.php";

require "header.php";
?>

<div class='container-fluid'>

<div class='row'>

<div id='headimage' class='col-12 text-center'>
<h1 style='margin-top:550px;' >Groups Club</h1><h4 style='margin-top:30px;' >Some Text</h4><p><a class="btn btn-block btn-danger" href="register.php" role="button">Join</a></p><p style='margin-top:50px;'>More text</p>
</div>

</div>

<?
require "footer.php";
?>


</div><!container>

<?
require "bootstrapbottom.php";
?>