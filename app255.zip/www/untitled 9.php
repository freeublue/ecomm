<?
require "bootstraptop.php";
require "functions/bootlib.php";
require "../confad.php";
echo "<div class='row text-center'>";
$sql = $db->query("SELECT * FROM groupcl LIMIT 3");
while($rows = $sql->fetchArray(SQLITE3_ASSOC ) ) { 




echo "<div id ='im1'  class='col-4'><h4 style='color:#f9f7f4;padding:8px;height:80px;'>$rows[gr_title]</h4><p style='color:#f9f7f4;background:#3a4660;padding:5px;opacity:0.6;height:100px;'>$rows[gr_descp] </p><p><a class='btn btn-sm btn-outline-light' href='grouppage.php?id=$rows[gr_id]' role='button'>Join</a></p>
</div>"; } 
?>
