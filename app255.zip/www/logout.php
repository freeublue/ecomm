<?
session_start();

require "bootstraptop.php";
require "functions/bootlib.php";
require "../confad.php";

require "header.php";

if(isset($_SESSION[customer]) ) {  
?>
<div class='container-fluid'>



<?php
// remove all session variables
session_unset(); 

// destroy the session 
session_destroy(); 
?>

echo "<a href='index.php'>Return Home You have been logged out</a>"; 


<? } 

else { echo "You must be logged in to proceed"; } 
require "footer.php";
?>




</div><!container>

<?
require "bootstrapbottom.php";
?>