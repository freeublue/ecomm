<?
session_start();

require "bootstraptop.php";
require "functions/bootlib.php";
require "../confad.php";
$size = 'xl';
$bootcolor = 'light';
$bootcolor2 = 'light';
$navname = 'Public Service Internship Club';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Categories >>', 'categories.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);
$id = $_REQUEST[groupid];
if(isset($_SESSION[customer]) ) {  

?>
<div class='container-fluid'>

<?

$sql = $db->query("SELECT * FROM groupmem WHERE gm_gid = '$id'");
while($rows = $sql->fetchArray(SQLITE3_ASSOC ) ) { 
$mentorid[] = $rows[gm_userid];

} 
foreach ($mentorid as $me) { 
$sq = $db->query("SELECT * FROM mentor WHERE mn_id = '$me'");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 


echo "<div class='col-4'><h4>$row[mn_title]</h4><img style='height:150px;width:150px;' src='$row[mn_image]' class='img-fluid rounded-circle' /><h3 style='color:#eee7e0;height:80px;margin-top:1em;border-bottom:#ceb7a2 1px solid;'>" . $row[mn_title] . "'s Background</h3><div style='padding:4px;border-left:1px dotted #eee7e0;border-right:1px dotted #eee7e0;'><p>$row[mn_descp]</p></div></div>"; } } 
?>




<? } 

else { echo "<h1>You must be a member of this group and logged in to proceed</h1>"; 
?>

<div class='row'>

<div class='col-6'>
      <form name='rform' onsubmit='return validateForm();' action='loginredir2.php' method='post' class="form-signin">
        <h2 class="form-signin-heading">Login</h2>
        <label for="input" class="sr-only">Mobile Number</label>
        <input type="input" name='mobile' id="mobile" class="form-control" placeholder="Mobile number" required autofocus>
        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" id="password" name='password' class="form-control" placeholder="Password" required>
        <input type='checkbox' name='join' >Click to join this Group
        <?
        
        echo "<input type='text' id='groupid' name='groupid' class='form-control' value='gr_id=$id' />"; 
       
        ?>
        <button class="btn btn-md btn-dark btn-block" type="submit">Sign in</button>
      </form>
</div>
<div class='col-6'>

<form action='regredirgroup.php' method='post' class="form-signin" onsubmit='return validateForm2();' name='rform2' id='form3'><h2 class="form-signin-heading">Enter your mobile number and select a password.</h2><p>Password can be letters and numbers only, no spaces in username or password. password must be 6 or more characters</p>
       <label for="input" class="sr-only">Mobile Number</label>
        <input type="input" name='us' id="us" class="form-control" placeholder="Mobile number" required autofocus>
        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" id="ps" name='ps' class="form-control" placeholder="Password" required>
         <label for="inputPassword" class="sr-only">Repeat Password</label>
        <input type="password" id="psr" name='psr' class="form-control" placeholder="Repeat Password" required>
         <?
        
        echo "<input type='text' id='groupidreg' name='groupidreg' class='form-control' value='gr_id=$id' />"; 
       
        ?>
        <button class="btn btn-md btn-dark btn-block" type="submit">Sign in</button>
      </form>
<p>By registering you agree to the terms and conditions as set out<a style='color:red;' href='terms.php'>Here</a></p></div>
</div>


</div>






<?

} 
require "footer.php";
?>




</div><!container>

<?
require "bootstrapbottom.php";
?>

