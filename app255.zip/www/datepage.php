<?
session_start();
$title = 'Public Service Internship Club Workshops By Date';
require "bootstraptop.php";
require "functions/bootlib.php";
require "../confad.php";
$size = 'xl';
$bootcolor = 'light';
$bootcolor2 = 'light';
$navname = 'Public Service Internship Club';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Categories >>', 'categories.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);

?>
<style>
#details{
padding:4px;
display:none;
position:absolute;
background:;
color:;
margin-top:30px;
z-index:5;


border: 1px solid #eee7e0;}
td{
height:90px;
width:90px;
border:1px dotted #eee7e0;}
.num{ 
color:teal;
margin-left:2px;
margin-top:-34px;
} 
.ap{
color:#ed8a63;
font-size:8px;
}</style>

<div class='container-fluid'>




<div style='margin-top:4em;' class="row text-center">
<div class="col-12">
<h4>News and Events.</h4>

    <h2 class="mb-5 font-weight-bold text-center">News and Events</h2><div id='details'></div>

   </div></div> <!--Grid row-->
    <div class="row">

        <!--Grid column-->
        <div class="col-md-12 mb-12">
        <?
         function days_in_month($year, $month) {
return round((mktime(0, 0, 0, $month+1, 1, $year) - mktime(0, 0, 0, $month, 1, $year)) / 86400);
} 
$dyday= $_POST[month];
$nowmonth = date($dyday);
$nowm = $nowmonth . '-01';

$y = strtotime($nowm);
$dr = getdate($y);
$g = $dr["mday"];

$yearb = intval($dr["year"]);
$monthb = $dr["mon"];
$fullmonth = $dr["month"];
$das = days_in_month($yearb, $monthb);
$endmonth = $nowmonth . '-' . $das;

echo "<h4 class='text-center'>$fullmonth $yearb </h4><br />"; 
$daysarray = range(1, $das, 1);
$appointments = range(1, $das, 1);
$wsid = range(1, $das, 1);
$sq = $db->query("SELECT * FROM workshop2 WHERE ws_datefr BETWEEN '$nowm' AND '$endmonth'");
while($rowz = $sq->fetchArray(SQLITE3_ASSOC)) { 

$daselect = substr($rowz[ws_datefr], -2);

if(substr($daselect, 0, 1) == 0 ) { 
$nax = substr($daselect, 0);

$appointments[$nax-1] = $rowz[ws_title];
$wsid[$nax-1] = $rowz[ws_id];
}  else { 
$nax = $daselect; 

$appointments[$nax-1] = "$rowz[ws_timefr] " . " $rowz[ws_title]";
$wsid[$nax-1] = $rowz[ws_id];
} 
} 



echo "<center><form name='dateForm' method='post' action='datepage.php'><input style='width:30%;' type='month' name='month' /><input style='width:160px;' type='submit' class='btn btn-sm btn-dark' name='submit' value='Select month' /></form></center>";

        echo "<center><table width='100%'>
        <tr>";
        for($i=0;$i<7;$i++) { 
        if(strlen($appointments[$i]) < 2) { 
        $ff = " "; } else { 
        $ff = $appointments[$i];
         }
        
        echo "<td><div class='num'>$daysarray[$i]</div><div id='$i' onclick='detailsOf(this.id);' class='ap'>$ff</div></td>"; }
        echo "</tr><tr>";
 
        for($i=7;$i<14;$i++) { 
         if(strlen($appointments[$i]) < 3) { 
        $ff = " "; } else { 
        $ff = $appointments[$i];
         }
        echo "<td><div class='num'>$daysarray[$i] </div><div id='$i' onclick='detailsOf(this.id);' class='ap'>$ff</div></td>"; }
        echo "</tr><tr>";
         
        for($i=14;$i<21;$i++) { 
          if(strlen($appointments[$i]) < 3) { 
        $ff = " "; } else { 
        $ff = $appointments[$i];
         }
        echo "<td><div class='num'>$daysarray[$i]  </div><div id='$wsid[$i]' onclick='detailsOf(this.id);' class='ap'>$ff</div></td>"; }
        echo "</tr><tr>";
         for($i=21;$i<28;$i++) { 
           if(strlen($appointments[$i]) < 3) { 
        $ff = " "; } else { 
        $ff = $appointments[$i];
         }
       
        echo "<td><div class='num'>$daysarray[$i]</div></td>"; }
         
        echo "</tr><tr>";
        for($i=28;$i<$das;$i++) { 
          if(strlen($appointments[$i]) < 3) { 
        $ff = " "; } else { 
        $ff = $appointments[$i];
         } 
        echo "<td><div class='num'>$daysarray[$i]</div><div id='$i' onclick='detailsOf(this.id);' class='ap'>$ff</div></td>"; }
                echo"</tr>
        </table></center>";
        ?>



</div>
</div>
 

 <?
require "footer.php";
require "bootstrapbottom.php";
?>


</div><!container>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js" type="text/javascript"></script>
    <script>
    var bb;
    function detailsOf(bb) { 
    
    
$.ajaxSetup({ cache: false }); 
document.getElementById("details").style.display = "block";

var url = "result.php?ele=" + bb;
$('#details').load(url);
    } 
    </script>


