<?
session_start();
$title = 'Groups and Workshops';
require "bootstraptop.php";
require "functions/bootlib.php";
include "../confad.php";

require "header.php";
?>
<script>
var i = 0;
var txt = 'Groups Club';
var speed = 250;

function type() {
  if (i < txt.length) {
    document.getElementById("demo").innerHTML += txt.charAt(i);
    i++;
    setTimeout(type, speed);
  }
}
</script>

<div  class='container-fluid'>

<div class='row'>

<div id='headimage' class='col-12 text-center'>
<h1 style='margin-top:550px;' id='demo'></h1><h4 style='margin-top:30px;'>Groups and Workshops</h4><p><a class="btn btn-block btn-light" href="register.php" role="button">Join</a></p><p style='margin-top:50px;'>Affording Employment Opportunities</p>
</div>

</div>


<div style='margin-top:2em;' class='row text-center'>

<div class='col-2'><i style='color:#eee7e0;' class="fas fa-graduation-cap"></i><p>Learn</p>
</div>
<div class='col-2'><i style='color:#eee7e0;' class="fas fa-chalkboard"></i><p>Teach</p>
</div>
<div class='col-2'><i style='color:#eee7e0;' class="fas fa-chalkboard-teacher"></i><p>Meet</p>
</div>
<div class='col-2'><i style='color:#eee7e0;' class="fas fa-chalkboard"></i><p>Connect</p>
</div>
<div class='col-2'><i style='color:#eee7e0;' class="fas fa-laptop"></i><p>Improve</p>
</div>
<div class='col-2'><i style='color:#eee7e0;' class="fas fa-desktop"></i><p>Instruct</p>
</div>




</div<?
$smb = $db->query("SELECT * FROM indtb WHERE ind_id = '1'");
while($rx = $smb->fetchArray(SQLITE3_ASSOC)) { 
echo "<div  style='background: #f4efea;' class='row text-center'>

<div style='padding:10px;border-bottom:1px solid #ed8a63;background:#f4efea;' class='col-12'>
<h2>Groups Club</h2>
<h4>$rx[ind_subhead]</h4>
<p style='color:#ed8a63;'>------ <i class='fab fa-twitter fa-1x' style='color:#ed8a63;'></i><i class='fab fa-instagram fa-1x' style='color:#ed8a63;'></i><i class='fab fa-facebook-f fa-1x' style='color:#ed8a63;'></i> ------</p>
<p>$rx[ind_txt]</p>

</div></div>"; } 
?>

<div  style='background: #f4efea;' class='row text-center'>

<div style='padding:10px;background:#f4efea;' class='col-12'>
<h2>Featured Groups</h2></div></div>
</div>

<div style='border-bottom:1px solid #ed8a63;height:300px;' class='row text-center'>
<?
$sql = $db->query("SELECT * FROM groupcl LIMIT 3");
while($rows = $sql->fetchArray(SQLITE3_ASSOC ) ) { 




echo "<div id ='im1'  class='col-4'><h4 style='color:#f9f7f4;padding:8px;height:80px;'>$rows[gr_title]</h4><p style='color:#f9f7f4;background:#3a4660;padding:5px;opacity:0.6;height:130px;'>$rows[gr_descp] </p><p><a class='btn btn-sm btn-outline-light' href='groupspage.php?id=$rows[gr_id]' role='button'>Join</a></p>
</div>"; } 
?>

</div>
<div  style='background: #f4efea;' class='row text-center'>

<div style='padding:10px;border-bottom:1px solid #ed8a63;background:#f4efea;' class='col-12'>
<h2>Categories</h2></div></div>
</div>
<?


echo "<div style='margin-top:5em;' class='row text-center'>";
$sql = $db->query("SELECT * FROM groupcate LIMIT 0, 4 ");
while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 
echo "<div style='background: #f4efea;border-radius:15%;' class='col-3'><h5 style='color:#ed8a63;padding:8px;height:60px;'>$row[gc_title]</h5><p style='color:#ceb7a2;height:50px;'>$row[gc_descp]</p><p><img ' src='$row[gc_image]' style='margin-top:1em;' class='rounded-circle img-fluid' /></p><p><a class='btn btn-sm btn-outline-warning' href='categorygroup.php?searchTerm=$row[gc_id]' role='button'>View</a></p>
</div>"; } 
echo "</div>";
echo "<div style='margin-top:5em;' class='row text-center'>";
$sql = $db->query("SELECT * FROM groupcate LIMIT 4, 4 ");
while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 
echo "<div style='background: #f4efea;border-radius:15%;' class='col-3'><h5 style='color:#ed8a63;padding:8px;height:60px;'>$row[gc_title]</h5><p style='color:#ceb7a2;height:50px;'>$row[gc_descp]</p><p><img ' src='$row[gc_image]' class='rounded-circle img-fluid' style='margin-top:1em;' /></p><p><a class='btn btn-sm btn-outline-warning' href='categorygroup.php?searchTerm=$row[gc_id]' role='button'>View</a></p>
</div>"; } 
?>

</div>
<?
$smb2 = $db->query("SELECT * FROM indtb WHERE ind_id = '2'");
while($rx2 = $smb2->fetchArray(SQLITE3_ASSOC)) { 

echo "<div  style='background: #3a4660;margin-top:5em;' class='row text-center'>

<div style='background:#3a4660;border-radius:15%;color:#f9f7f4;' class='col-12'>
<h2>$rx2[ind_title]</h2>
<h4>$rx2[ind_subhead]</h4>
<p>$rx2[ind_txt] </p>  
</div>

</div>"; } 
?>
<div style='background:#3a4660;color:#f9f7f4;height:500px;border:solid 1px #ed8a63;' class='row text-center'>
<div class='col-6'><h4 style='margin-top:10px;'>Search Groups</h4><i class="fas fa-search fa-2x" style='color:#ed8a63;'></i><br><p>Groups available in each province nationwide. select your area and your career field. Find a group to suit these parameters, join and browse variois workshops, which are designed and optimised to improve employment options. From CV enhancement to self-presentation, Public Service Internship Club has you covered. Each study section is conviently discounted for interns who subscribe to services, thereby earning extra discounts and securing the latest information, ahead of the pack.</p><p><a class="btn btn-sm btn-outline-light" href="searchgroup.php" role="button">Search >></a></p>
</div>
<div class='col-6'><h4 style='margin-top:10px;'>Join a Group</h4><i class="fas fa-plus fa-2x" style='color:#ed8a63;'></i><br><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p><p><a class="btn btn-sm btn-outline-light" href="categories.php" role="button">Join >></a></p>
</div>
</div>


<div  style='background: #3a4660;color:#f9f7f4;' class='row text-center'>

<div  class='col-12'>
<h2>Areas and Info</h2>
<h4>Discover Groups</h4></div>
</div>


<?
echo "<div  style='background: #3a4660;color:#f9f7f4;padding:12px;' class='row'>";
echo "<div  class='col-4'>";
echo "<b style='color:#eee7e0;'>Provincial Groups</b>";

$sql = $db->query("SELECT * FROM locate");
while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 
$province[] = $row[lc_title];
$pid[] = $row[lc_id]; } 
$sizesx = 9;
$stylex = 'liststy';
$listx = 'ul';
$clax = 'list-unstyled';
$contx = array("<a style='text-decoration:none;color:#f9f7f4;' href='groupsbyprovince.php?province=$pid[0]'>$province[0]</a>", "<a style='text-decoration:none;color:#f9f7f4;' href='groupsbyprovince.php?province=$pid[1]'>$province[1]</a>", "<a style='text-decoration:none;color:#f9f7f4;' href='groupsbyprovince.php?province=$pid[2]'>$province[2]</a>", "<a style='text-decoration:none;color:#f9f7f4;' href='groupsbyprovince.php?province=$pid[3]'>$province[3]</a>", "<a style='text-decoration:none;color:#f9f7f4;' href='groupsbyprovince.php?province=$pid[4]'>$province[4]</a>", "<a style='text-decoration:none;color:#f9f7f4;' href='groupsbyprovince.php?province=$pid[5]'>$province[5]</a>", "<a style='text-decoration:none;color:#f9f7f4;' href='groupsbyprovince.php?province=$pid[6]'>$province[6]</a>", "<a style='text-decoration:none;color:#f9f7f4;' href='groupsbyprovince.php?province=$pid[7]'>$province[7]</a>", "<a style='text-decoration:none;color:#f9f7f4;' href='groupsbyprovince.php?province=$pid[8]'>$province[8]</a>");
$optstylex = array('tt1', 'tt2', 'tt3', 'tt4', 'tt5', 'tt6');
$lisx = blist($stylex, $listx, $clax, $sizex, $contx, $optstylex);
echo $lisx;
?>




</div>
<div  class='col-4'><b style='color:#eee7e0;'>Featured Groups</b></div>
<div  class='col-4'><b style='color:#eee7e0;'>Services</b></div>
</div>

<div  style='background: #3a4660;color:#f9f7f4;' class='row text-center'>

<div  class='col-12'>
<p class="m-0 text-center text-#f9f7f4">Copyright &copy; Groups and Workshops 2018</p><p style='text-align:center;'><i class="fab fa-twitter fa-1x" style='color:#ed8a63;'></i><i class="fab fa-instagram fa-1x" style='color:#ed8a63;'></i><i class="fab fa-facebook-f fa-1x" style='color:#ed8a63;'></i></p><p><img height='30px' src='vm.png' /></p>
</div>

</div>


</div><!container><div class='subs_popup'><h4>Sign up for our weekly Newsletter<div onclick='close_pu();' id='close_popup'>X</div></h4><img src='logo.png' style='float:right;' height='150px'/>
<form name='mailform'><h4>Subscribe</h4><b>Name: </b><input style='color:#ceb7a2' type='text' name='nam' /><br /><b>Email: </b><input type='text' style='color:#3a4660' name='mail' /><br /><center><div class="btn btn-dark" onclick='showmail();' />SUBSCRIBE</div></center></form><div id='resultsx'>x</div></div>
<?
require "bootstrapbottom.php";
?>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js" type="text/javascript"></script>
<script>
var mail;
var nam;
function showmail() { 
$.ajaxSetup({ cache: false });
$("#resultsx").show();
var nam = document.mailform.nam.value;
var mail = document.mailform.mail.value;
var url = "addmail.php?nam="+nam+"&&mail="+mail;
$('#resultsx').load(url);
} 
function close_pu() { 
$(".subs_popup").hide();
} </script>

