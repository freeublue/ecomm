<?
session_start();

require "bootstraptop.php";
require "functions/bootlib.php";

require "../confad.php";

require "header.php";

if(isset($_SESSION[customer]) ) {  

require "../lib.php";
$customer = cr($stp, ($_SESSION[customer]), $action = 'enc');
$sqlc = $db->query("SELECT * FROM cust1 WHERE cu_phone_mobile = '$customer'");
while($row = $sqlc->fetchArray(SQLITE3_ASSOC) ) { 
$newcustid = $row[cu_id]; } 
$sql = $db->query("SELECT * FROM ordnum");
while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 
$numold = $row[od_num]; 
$numnew = $numold + 1;} 

?>
<div class='container-fluid'>
<style>

#conf1{padding:10px;
color:;
background:; 
border-radius:0px 30px 30px 0px;}
#confirm{background:;}

#conf2{padding:10px;
color:;
background:#ceb7a2;
border-right:1px solid #ceb7a2;
border-radius:0px 30px 30px 0px;}
#conf3{padding:10px;
color:;
background:;
border-right:1px solid #ceb7a2;
border-radius:0px 30px 30px 0px; }
#arrow_box {
	position: relative;
	background: ;
	border: 1px solid #0d020f;
}
#arrow_box:after, .arrow_box:before {
	left: 100%;
	top: 50%;
	border: solid transparent;
	content: " ";
	height: 0;
	width: 0;
	position: absolute;
	pointer-events: none;
}

#arrow_box:after {
	border-color: rgba(242, 242, 242, 0);
	border-left-color: ;
	border-width: 90px;
	margin-top: -90px;
}
#arrow_box:before {
	border-color: rgba(13, 2, 15, 0);
	border-left-color: #0d020f;
	border-width: 91px;
	margin-top: -91px;
}
</style>
<?
$id = "confirm";
$size = 3;
$rule = 'text-center';
$colsize = 'col-4';
$gg = array('conf1', 'conf2', 'conf3');
$contentarray[0] = "<h5>Confirm >></h5>";
$contentarray[1] = "<h5>Payment >></h5>";
$contentarray[2] = "<h5>Notification >></h5>";
rowcol($id, $rule, $size, $contentarray, $colsize, $gg);
$mobile = $_POST[mb];
$email = $_POST[em];
$fname = $_POST[name_first];
$lname = $_POST[name_last];
$amount = $_POST[amount];
$pt = $_POST[paytype];
$ti = $_POST[type];
$subad = $_POST[subad];
$orstatus = 2;
$wsid = $_POST[id];
$tb = "wsorders";


$day = date("Y-m-d");
$timep = date("H:i");
echo "mobile $mobile<br>email $email <br>fname $fname <br> Lname $lname <br>Amount $amount <br> Paytype $pt<br>Type $ti<br>Subad $subad<br>Status $orstatus <br> ID $wsid<br>"; 
$sw = $db->query("INSERT INTO wsorders(wo_ordernum, wo_clientid, wo_wsid, wo_producttype, wo_price, wo_orderdate, wo_ordertime, wo_discounttype, wo_discountamount, wo_orderfeatures, wo_orderstatus, wo_paymenttype, wo_paymentstatus) values('$numnew', '$newcustid', '$wsid', '$ti', '$amount', '$day', '$timep', '$clnu', '$discountamount', '$features', '$orstatus', '$pt', '1')");
$xz = $db->query("UPDATE ordnum SET od_num = '$numnew'");

echo "$pt<br>";
$tableclassx = 'table-striped';
$rowcountx = 6;
$contex = array('Name', 'Mobile', 'Email', 'Payment Method', 'Product', 'Total', $fname , $lname, $_SESSION[customer], $email, $paytype, $ti, 'R' . $amount);
      
$id = 'tsty';
$rowcount = 2;
$conte = array('Name', 'Name', 'Mobile', 'Email', 'Payment Method', 'Product', 'Total', $fname, $lname, $_SESSION[customer], $email, $pt, $ti, $amount);
$tableclass = 'table table-bordered';
      
      ?>



<div style='margin-top:5em;' class='row'>
<div class='col-12'><h4 style='color:#ceb7a2;'>Payment Details</h4>
<?
btable($id, $tableclass, $rowcount, $conte, $optsid);
?>
<h4 style='color:#ceb7a2;'>Payfast</h4><p>You will be directed to the Payfast, secure payment gateway. we do not store card details on this website.</p><p>No shipping details are necassary for this product.</p>
</div>
</div>
<?php 



// Construct variables 

$data = array(
    // Merchant details
    'merchant_id' => '10010678',
    'merchant_key' => 'agwrp9i76eqco',
    'return_url' => "https://www.publicserviceinternshipclub.co.za/www/successbuy.php?payid=$numnew&&type=$ti",
    'cancel_url' => "https://www.publicserviceinternshipclub.co.za/www/cancelbuy.php?payid=$numnew&&type=$ti",
    'notify_url' => "https://www.publicserviceinternshipclub.co.za/www/notifybuy.php?payid=$numnew&&type=$ti",
    // Buyer details
    'name_first' => $fname,
    'name_last'  => $lname,
    'email_address'=> 'sbtu01@payfast.co.za',
    // Transaction details
    'm_payment_id' => $numnew, 
    
    
    'amount' => number_format( sprintf( "%.2f", $amount ), 2, '.', '' ),
    'item_name' => 'workshops',
    'item_description' => 'Details of workshop on your account',
    'custom_int1' => $newcustid,           
    'custom_str1' => 'Thank you for your purchase' . $_SESSION[customer]
);        

// Create GET string
$pfOutput = '';
foreach( $data as $key => $val )
{
    if(!empty($val))
     {
        $pfOutput .= $key .'='. urlencode( trim( $val ) ) .'&';
     }
}

$getString = substr( $pfOutput, 0, -1 );

$passPhrase = 'amagreatGirl44';
if( isset( $passPhrase ) )
{
    $getString .= '&passphrase='. urlencode( trim( $passPhrase ) );
}   
$data['signature'] = md5( $getString );


$testingMode = true;
$pfHost = $testingMode ? 'sandbox.payfast.co.za' : 'www.payfast.co.za';
$htmlForm = '<form action="https://'.$pfHost.'/eng/process" method="post">'; 
foreach($data as $name=> $value)
{ 
    $htmlForm .= '<input name="'.$name.'" type="hidden" value="'.$value.'" />'; 
} 
$htmlForm .= '<input class="btn btn-dark" type="submit" value="Pay Now" /></form>'; 
echo $htmlForm;
$ema2 = $_POST[em];
$messagews = "<b>Thank you for your purchase. Welcome to workshops Details of your purchase are available on your account </b>";
$messagebod = 'https://publicserviceinternshipclub.co.za/www/ypage.php';
$messagenext = "A total of $total has been request form Payfast. A Confirmation email will arrive shortlyif the payment is sucessful.";
$message = $messagews . $messagebod;
$subject = 'Workshop Purchase';
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
//Additional headers
$headers .= 'To:' . $fname . $lname . '<' . $ema2 . '>' . "\r\n";
$headers .= 'From: Public Service Internship Club Webstore <admin@publicserviceinternshipclub.co.za>' . "\r\n";
$headers .= 'Cc: ';
$headers .= 'Bcc: '; 
$ar = array($ema2 . ', ', 'susan.hern@icloud.com, ');
//implode means turn array into a sentence
$headers .=implode(',', $ar);
// Mail it
$to = $ema2;
mail($to, $subject, $message, $headers);
 



 } 

else { echo "You must be logged in to proceed"; } 
require "footer.php";
?>




</div><!container>

<?
require "bootstrapbottom.php";
?>