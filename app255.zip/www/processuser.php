<?
session_start();

require "bootstraptop.php";
require "functions/bootlib.php";
require "../confad.php";
require "header.php";

if(isset($_SESSION[customer]) ) {  









} 
?>