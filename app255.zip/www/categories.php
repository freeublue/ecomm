<?
require "bootstraptop.php";
require "functions/bootlib.php";
require "header.php";
?>

<div class='container-fluid'>

<div class='row'>

<div id='headstart' class='col-12 text-center'>
<h1 style='margin-top:450px;' >Categories</h1><h4 style='margin-top:30px;' >Some Text</h4><p style='margin-top:50px;'>More text</p>
</div>

</div><!row>
<div class='row'>
<div class='col-6'><h1 style='font-size:28px;text-align:center;border-bottom:1px solid red;padding:4px;'>Categories</h1><form><label>Select Province</label>
<select id='prov' name='prov'>
<option value='Gauteng'>Gauteng</option>
</select></form><br><ul class='list-unstyled'>
<?
require "../confad.php";
$sql = $db->query("SELECT * FROM groupcate");
while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 

echo "<li><a style='text-decoration:none;color:#ceb7a2;' href='categorygroup.php?searchTerm=$row[gc_id]'>$row[gc_title] </a></li>"; } 
?>
</ul></div>
<div class='col-6'><h1 style='font-size:28px;text-align:center;border-bottom:1px solid red;padding:4px;'>Provinces</h1>

</div>
</div><!row>
<?
require "footer.php";
?>




 








</div><!container>

<?
require "bootstrapbottom.php";
?>